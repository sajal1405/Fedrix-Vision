// postcss.config.js
// PostCSS configuration for processing CSS with Tailwind CSS and Autoprefixer.
// This file is essential for Tailwind to compile your CSS.
module.exports = {
  plugins: {
    // Tailwind CSS plugin for PostCSS. It processes your CSS to include Tailwind's utility classes.
    tailwindcss: {},
    // Autoprefixer plugin for PostCSS. It adds vendor prefixes to your CSS rules
    // for broader browser compatibility (e.g., -webkit-, -moz-).
    autoprefixer: {},
  },
};

