// jest.config.js
// Configuration file for Jest, the JavaScript testing framework.
// It defines how Jest should find and run tests, and sets up the testing environment.
module.exports = {
  // Specify the test environment. 'jsdom' is used for browser-like environments
  // to test React components.
  testEnvironment: "jsdom",

  // Files to run before each test file. This is where you might set up global mocks
  // or polyfills needed for your tests.
  setupFilesAfterEnv: ["<rootDir>/src/setupTests.js"],

  // Jest will transform files using babel-jest by default for JS/JSX.
  // If you have specific file types or custom transformations, you might add:
  // transform: {
  //   '^.+\\.(js|jsx|ts|tsx)$': 'babel-jest',
  // },

  // Module file extensions Jest should look for.
  moduleFileExtensions: ["js", "jsx", "json", "node"],

  // A map from regular expressions to module names that allow to stub out resources
  // like images or CSS files with a single mock.
  moduleNameMapper: {
    // Example: For CSS imports, map them to an empty object
    "\\.(css|less|scss|sass)$": "identity-obj-proxy",
    // Example: For image imports, map them to a mock file
    "\\.(gif|ttf|eot|svg|png)$": "<rootDir>/src/__mocks__/fileMock.js",
  },

  // An array of glob patterns that Jest should use to detect test files.
  // By default, Jest looks for files with .js, .jsx, .ts, .tsx extensions
  // in __tests__ folders, as well as any files with a .test. or .spec. suffix.
  testMatch: [
    "<rootDir>/src/**/*.{spec,test}.{js,jsx,ts,tsx}"
  ],

  // An array of regexp patterns that Jest uses to skip transforming files.
  // Node modules are typically excluded to speed up tests.
  transformIgnorePatterns: [
    "[/\\\\]node_modules[/\\\\].+\\.(js|jsx|mjs|cjs|ts|tsx)$",
  ],

  // Collect test coverage.
  collectCoverage: false, // Set to true to enable coverage collection
  collectCoverageFrom: [
    "src/**/*.{js,jsx,ts,tsx}",
    "!src/**/*.d.ts",
    "!src/index.js", // Exclude main entry file
    "!src/serviceWorkerRegistration.js", // Exclude service worker registration
    "!src/setupTests.js", // Exclude test setup file
  ],
  coverageDirectory: "coverage",
  coverageReporters: ["json", "lcov", "text", "clover"],
};

