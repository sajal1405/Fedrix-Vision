// desktop/preload.js
// This script runs before your web page is loaded in the renderer process.
// It has access to Node.js APIs and is useful for exposing Node.js functionalities
// to the renderer process in a controlled way, enhancing security through context isolation.

// Listen for the DOMContentLoaded event, which fires when the HTML document
// has been completely loaded and parsed, without waiting for stylesheets, images,
// and subframes to finish loading.
window.addEventListener("DOMContentLoaded", () => {
  // Example: Log a message to the main process console (visible if dev tools are open or in Electron's console)
  // This is a simple example; in a real app, you might expose a more sophisticated API
  // to the renderer process using `contextBridge` for secure inter-process communication.
  // console.log("Fedrix Desktop App Initialized from preload script.");
});

// Example of how to expose an API securely if contextIsolation is true (default from Electron 12+):
// const { contextBridge, ipcRenderer } = require('electron');

// contextBridge.exposeInMainWorld('electronAPI', {
//   // Example: A function to send a message to the main process
//   sendMessage: (message) => ipcRenderer.send('message-from-renderer', message),
//   // Example: A function to receive messages from the main process
//   onUpdateCounter: (callback) => ipcRenderer.on('update-counter', (event, value) => callback(value))
// });
