// desktop/main.js
// This is the main process file for the Electron desktop application.
// It handles window creation, application lifecycle events, and basic settings.
const { app, BrowserWindow } = require("electron");
const path = require("path");

let mainWindow; // Global reference to the main window object

/**
 * Creates the main application window.
 */
function createWindow() {
  mainWindow = new BrowserWindow({
    fullscreen: true, // Start in fullscreen mode
    autoHideMenuBar: true, // Hide the menu bar
    backgroundColor: "#000", // Set initial background color to black
    webPreferences: {
      // Preload script to run before other scripts in the renderer process
      preload: path.join(__dirname, "preload.js"),
      // Enable Node.js integration in the renderer process (be cautious with this in production)
      nodeIntegration: true,
      // Context Isolation is true by default from Electron 12, explicitly set for clarity if needed.
      // contextIsolation: true,
    },
  });

  // Define the base URL for the React app.
  // In development, this is typically http://localhost:3000.
  // In production builds, it might point to a local file system path or bundled assets.
  const baseUrl = process.env.DESKTOP_BASE_URL || "http://localhost:3000";

  // Define a mapping of dashboard routes.
  // This allows the Electron app to directly load specific parts of the web app.
  const dashboardRoutes = {
    main: `${baseUrl}/dashboard`,
    kanban: `${baseUrl}/dashboard/kanban`,
    calendar: `${baseUrl}/dashboard/calendar`,
    blog: `${baseUrl}/dashboard/blog`,
    agent: `${baseUrl}/dashboard/agent`,
    users: `${baseUrl}/dashboard/users`,
    profile: `${baseUrl}/dashboard/profile`,
    settings: `${baseUrl}/dashboard/settings`,
    // Add any new routes here if you want to allow direct access from Electron
  };

  // Load the main dashboard route by default when the app starts.
  mainWindow.loadURL(dashboardRoutes.main);

  // Open the DevTools. This is useful for debugging in development.
  // mainWindow.webContents.openDevTools();

  // Dereference the window object when the window is closed.
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

// Electron app lifecycle events:

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(createWindow);

// Quit when all windows are closed, except on macOS.
// On macOS, it's common for applications and their menu bar
// to stay active until the user quits explicitly with Cmd + Q.
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

// On macOS, it's common to re-create a window in the app when the dock icon is clicked and there are no other windows open.
app.on("activate", () => {
  if (mainWindow === null) {
    createWindow();
  }
});

