// src/context/AgentAIContext.js
// Provides AI content generation capabilities to the application using the Gemini API.
// It manages the loading state and the generated content.
import React, { createContext, useState } from 'react';
import PropTypes from 'prop-types';

// Create the AgentAIContext with default values
export const AgentAIContext = createContext({
  generated: '', // The last generated AI content
  loading: false, // Indicates if AI content is currently being generated
  generateContent: async () => '', // Function to trigger AI content generation
});

// AgentAIProvider component to wrap the application and provide AI context
export const AgentAIProvider = ({
  children,
  generated: initialGenerated = '',
}) => {
  const [generated, setGenerated] = useState(initialGenerated); // State for generated content
  const [loading, setLoading] = useState(false); // State for loading status

  /**
   * Calls the Gemini API to generate text content based on a given prompt.
   * Uses 'gemini-2.0-flash' model by default.
   * @param {string} prompt - The text prompt to send to the AI model.
   * @returns {Promise<string>} The generated text content, or an empty string on error.
   */
  const generateContent = async (prompt) => {
    setLoading(true); // Set loading to true while generation is in progress
    setGenerated(''); // Clear previous generated content

    const apiKey = ''; // API key will be automatically provided by Canvas runtime if empty
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    let chatHistory = [];
    chatHistory.push({ role: 'user', parts: [{ text: prompt }] }); // Format prompt for Gemini API

    const payload = {
      contents: chatHistory,
      // Optional: Add generationConfig for structured responses or safety settings if needed
      // generationConfig: {
      //   responseMimeType: "application/json",
      //   responseSchema: { ... }
      // }
    };

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      // Check if the network request was successful
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `API Error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`,
        );
      }

      const result = await response.json();

      // Parse the response to extract the generated text
      if (
        result.candidates &&
        result.candidates.length > 0 &&
        result.candidates[0].content &&
        result.candidates[0].content.parts &&
        result.candidates[0].content.parts.length > 0
      ) {
        const text = result.candidates[0].content.parts[0].text;
        setGenerated(text); // Update state with the generated text
        return text;
      } else {
        console.warn(
          'AI content generation response structure unexpected or empty.',
        );
        setGenerated('Failed to generate content: Unexpected response.');
        return '';
      }
    } catch (err) {
      console.error('AI content generation failed:', err);
      setGenerated(
        `Failed to generate content: ${err.message || 'Network error'}.`,
      );
      return '';
    } finally {
      setLoading(false); // Set loading to false once generation is complete (or errors)
    }
  };

  // Provide the generated content, loading status, and generation function to children
  return (
    <AgentAIContext.Provider value={{ generated, loading, generateContent }}>
      {children}
    </AgentAIContext.Provider>
  );
};

// PropTypes for AgentAIProvider to ensure 'children' is a valid React node
AgentAIProvider.propTypes = {
  children: PropTypes.node.isRequired,
  initialGenerated: PropTypes.string, // Optional initial content for testing/SSR
};
