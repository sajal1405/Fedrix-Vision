// src/context/AuthContext.js
import { supabase } from '../supabaseClient';
import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from 'react';

const AuthContext = createContext(null);

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Supabase auth state changed:', event, session?.user?.id);
      if (event === 'SIGNED_IN' && session) {
        setCurrentUser(session.user);
      } else if (event === 'SIGNED_OUT') {
        setCurrentUser(null);
      } else if (event === 'INITIAL_SESSION' && session) {
        setCurrentUser(session.user);
      } else if (event === 'USER_UPDATED' && session) {
        setCurrentUser(session.user);
      }
      setIsLoading(false);
      setIsAuthReady(true);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setCurrentUser(session.user);
      }
      setIsLoading(false);
      setIsAuthReady(true);
      console.log(
        'Initial session check. User:',
        session?.user?.email,
        'Is Authenticated:',
        !!session?.user,
      );
    });

    return () => {
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  const signIn = useCallback(async (email, password) => {
    setIsLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      setCurrentUser(data.user);
      console.log('Supabase login successful:', data);
      return { success: true };
    } catch (err) {
      console.error('Login Error:', err.message);
      setError(err.message);
      return { success: false, error: err.message };
    } finally {
      setIsLoading(false);
    }
  }, []);

  // CONFIRMED: Calling signOut WITHOUT any scope parameter
  const signOut = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.signOut(); // This is the crucial line. No parameters.
      if (error) throw error;
      setCurrentUser(null);
      return { success: true };
    } catch (err) {
      console.error('Logout Error:', err.message);
      setError(err.message);
      return { success: false, error: err.message };
    } finally {
      setIsLoading(false);
    }
  }, []);

  const value = {
    currentUser,
    isLoading,
    error,
    isAuthReady,
    signIn,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
