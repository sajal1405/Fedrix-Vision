// src/context/UserProfileContext.js
import React, { createContext, useContext, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { supabase } from '../supabaseClient'; // Assuming supabaseClient.js is in src/

const UserProfileContext = createContext();

export const useUserProfile = () => {
  const context = useContext(UserProfileContext);
  if (context === undefined) {
    throw new Error('useUserProfile must be used within a UserProfileProvider');
  }
  return context;
};

export const UserProfileProvider = ({ children }) => {
  const [userProfile, setUserProfile] = useState(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);
  const [profileError, setProfileError] = useState(null);

  // Function to fetch the user profile
  const fetchUserProfile = useCallback(async (userId) => {
    if (!userId) {
      setUserProfile(null);
      setIsLoadingProfile(false);
      return;
    }

    setIsLoadingProfile(true);
    setProfileError(null);

    try {
      // --- IMPORTANT CHANGE: Simplified select to '*' to debug 406 error ---
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*') // Select all columns
        .eq('id', userId)
        .single();

      if (error && error.code === 'PGRST116') {
        // PGRST116 is "No rows found"
        console.log(
          'No existing profile found, attempting to create a new one.',
        );
        const { data: newProfile, error: newProfileError } = await supabase
          .from('user_profiles')
          .insert({
            id: userId,
            full_name: '', // User can fill this in
            avatar_url: 'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR', // Default placeholder
            notification_preferences: {}, // Default empty object
            theme_preference: 'system', // Default value
            role: 'user', // Default role for new users
          })
          .select('*') // Select all columns from the newly inserted row
          .single();

        if (newProfileError) throw newProfileError;
        setUserProfile(newProfile);
      } else if (error) {
        throw error;
      } else {
        setUserProfile(data);
      }
    } catch (err) {
      console.error('Error fetching or creating user profile:', err);
      // Log the full error object to get more details if it's a Supabase error
      console.error(
        'Supabase Error details:',
        err.details,
        err.hint,
        err.message,
        err.code,
      );
      setProfileError(err);
      setUserProfile(null); // Clear profile on error
    } finally {
      setIsLoadingProfile(false);
    }
  }, []);

  // Function to update the user profile
  const updateUserProfile = useCallback(
    async (updates) => {
      if (!userProfile?.id) {
        setProfileError(new Error('No user profile to update.'));
        return {
          success: false,
          error: new Error('No user profile ID available.'),
        };
      }

      setIsLoadingProfile(true);
      setProfileError(null);

      try {
        // --- IMPORTANT CHANGE: Simplified select to '*' for update return ---
        const { data, error } = await supabase
          .from('user_profiles')
          .update(updates)
          .eq('id', userProfile.id)
          .select('*') // Select all columns to get the latest state
          .single();

        if (error) {
          throw error;
        }

        setUserProfile(data); // Update local state with the new data
        return { success: true, data };
      } catch (err) {
        console.error('Error updating user profile:', err);
        console.error(
          'Supabase Error details:',
          err.details,
          err.hint,
          err.message,
          err.code,
        );
        setProfileError(err);
        return { success: false, error: err };
      } finally {
        setIsLoadingProfile(false);
      }
    },
    [userProfile],
  );

  // Provide the profile data and functions to children
  const value = {
    userProfile,
    isLoadingProfile,
    profileError,
    fetchUserProfile,
    updateUserProfile,
  };

  return (
    <UserProfileContext.Provider value={value}>
      {children}
    </UserProfileContext.Provider>
  );
};

UserProfileProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
