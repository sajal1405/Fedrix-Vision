// src/index.js
// The entry point for the React application.
// It sets up the root DOM element and renders the main App component.
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'; // Import the main App component
import './index.css'; // Import the main Tailwind-enhanced CSS file for global styles
import AOS from 'aos'; // Import AOS for "Animate On Scroll" effects
import 'aos/dist/aos.css'; // AOS default styles
import { AnimatePresence } from 'framer-motion'; // For managing exit animations with Framer Motion
import ErrorBoundary from './components/common/ErrorBoundary.jsx'; // Global error boundary
import * as serviceWorkerRegistration from './serviceWorkerRegistration'; // Service worker for PWA features

// Initialize AOS (Animate On Scroll) library with desired configurations.
AOS.init({
  once: true, // Whether animation should happen only once - default true
  delay: 50, // Values from 0 to 3000, with step 50ms
  duration: 800, // Values from 0 to 3000, with step 50ms
  easing: 'ease-in-out', // default easing for AOS animations
});

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <AnimatePresence mode="wait">
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </AnimatePresence>
  </React.StrictMode>,
);

// IMPORTANT: Unregister the service worker to prevent caching issues.
// We are temporarily disabling service worker functionality to debug persistent network request issues.
serviceWorkerRegistration.unregister();
// If you decide to re-enable it later, change this back to serviceWorkerRegistration.register();
