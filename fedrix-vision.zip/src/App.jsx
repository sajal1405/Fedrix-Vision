// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { UserProfileProvider } from './context/UserProfileContext';
import { SidebarProvider } from './context/SidebarContext';

// Layout Components
import DashboardLayout from './components/layout/DashboardLayout';

// Page Components
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import ResetPasswordPage from './pages/auth/ResetPasswordPage';

import Dashboard from './pages/Dashboard';
import OllamaDashboard from './pages/OllamaDashboard';
import ProfileSettings from './pages/ProfileSettings';
import ComingSoon from './pages/ComingSoon';
import Unauthorized from './pages/Unauthorized';

// Route Protectors
import PublicRoute from './components/routes/PublicRoute';

// New: Import Custom Cursor
import CustomCursor from './components/common/CustomCursor';

import './index.css';

function App() {
  return (
    <Router>
      <AuthProvider>
        <UserProfileProvider>
          <SidebarProvider>
            <CustomCursor /> {/* Render CustomCursor here globally */}
            <Routes>
              {/* Public Routes */}
              <Route
                path="/login"
                element={
                  <PublicRoute>
                    <LoginPage />
                  </PublicRoute>
                }
              />
              <Route
                path="/register"
                element={
                  <PublicRoute>
                    <RegisterPage />
                  </PublicRoute>
                }
              />
              <Route
                path="/forgot-password"
                element={
                  <PublicRoute>
                    <ForgotPasswordPage />
                  </PublicRoute>
                }
              />
              <Route
                path="/reset-password"
                element={
                  <PublicRoute>
                    <ResetPasswordPage />
                  </PublicRoute>
                }
              />
              <Route
                path="/unauthorized"
                element={
                  <PublicRoute>
                    <Unauthorized />
                  </PublicRoute>
                }
              />

              {/* Protected Routes - All nested under DashboardLayout */}
              <Route path="/" element={<DashboardLayout />}>
                <Route index element={<Dashboard />} />
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="ollama" element={<OllamaDashboard />} />
                <Route path="settings" element={<ProfileSettings />} />
                <Route
                  path="projects"
                  element={<ComingSoon pageName="Projects" />}
                />
                <Route
                  path="calendar"
                  element={<ComingSoon pageName="Calendar" />}
                />
                <Route
                  path="admin"
                  element={<ComingSoon pageName="Admin Panel" />}
                />
                <Route
                  path="*"
                  element={<ComingSoon pageName="Page Not Found" />}
                />
              </Route>
            </Routes>
          </SidebarProvider>
        </UserProfileProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
