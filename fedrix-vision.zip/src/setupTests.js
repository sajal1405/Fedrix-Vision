// src/setupTests.js
// This file is executed before running any tests with Jest.
// It's typically used for setting up the testing environment,
// polyfills, and global mocks.
import '@testing-library/jest-dom'; // Extends Jest's matchers with custom DOM matchers for testing React components.

// Mock environment variables for testing purposes.
// This ensures that tests do not fail due to missing environment variables
// that are usually provided at runtime (e.g., by Create React App or your CI/CD).
// Use dummy URLs and keys that won't attempt to connect to actual services during tests.
process.env.REACT_APP_SUPABASE_URL = 'http://localhost-test-url'; // Mock Supabase URL
process.env.REACT_APP_SUPABASE_ANON_KEY = 'mock-supabase-anon-key'; // Mock Supabase Anon Key
process.env.REACT_APP_HF_API_URL = 'http://localhost-huggingface-api-test'; // Mock HuggingFace API URL

// You can add other global setup here, such as:
// - Mocking browser APIs (e.g., window.matchMedia, localStorage)
// - Setting up global test utilities
// - Initializing a test database connection (less common for frontend tests)

// Example: Mocking localStorage
const localStorageMock = (function () {
  let store = {};
  return {
    getItem: function (key) {
      return store[key] || null;
    },
    setItem: function (key, value) {
      store[key] = value.toString();
    },
    removeItem: function (key) {
      delete store[key];
    },
    clear: function () {
      store = {};
    },
  };
})();
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

// Example: Mocking IntersectionObserver for components that use it (e.g., for lazy loading, AOS)
class IntersectionObserver {
  constructor(callback, options) {
    this.callback = callback;
    this.options = options;
  }
  observe() {}
  unobserve() {}
  disconnect() {}
}
Object.defineProperty(window, 'IntersectionObserver', {
  writable: true,
  configurable: true,
  value: IntersectionObserver,
});
Object.defineProperty(global, 'IntersectionObserver', {
  writable: true,
  configurable: true,
  value: IntersectionObserver,
});

// Mock matchMedia for responsive component testing
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(), // Deprecated
    removeListener: jest.fn(), // Deprecated
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});
