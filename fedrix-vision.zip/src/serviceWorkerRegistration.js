// src/serviceWorkerRegistration.js
// This file is responsible for registering the service worker,
// enabling Progressive Web App (PWA) features like offline support and caching.
// It's based on Create React App's default service worker setup.

// Determines if the app is running on localhost, which has implications for service worker caching.
const isLocalhost = Boolean(
  window.location.hostname === 'localhost' ||
    // IPv6 localhost address.
    window.location.hostname === '[::1]' ||
    // 127.0.0.0/8 are considered localhost for IPv4.
    /^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/.test(
      window.location.hostname,
    ),
);

/**
 * Registers the service worker.
 * @param {object} [config] - Optional configuration object with callbacks for onUpdate and onSuccess.
 */
export function register(config) {
  // Only register in production environment and if service worker API is supported by the browser.
  if (process.env.NODE_ENV === 'production' && 'serviceWorker' in navigator) {
    // The URL constructor is helpful for parsing URLs.
    // In this case, we ensure the public URL is on the same origin as the app
    // to prevent issues with cross-origin service worker registration.
    const publicUrl = new URL(process.env.PUBLIC_URL, window.location.href);
    if (publicUrl.origin !== window.location.origin) {
      // Our service worker won't work if PUBLIC_URL is on a different origin
      // from where our page is served. This might happen if a CDN is used to
      // serve assets; see https://github.com/facebook/create-react-app/issues/2374
      return;
    }

    // Listen for the 'load' event on the window to register the service worker
    // after the entire page has loaded.
    window.addEventListener('load', () => {
      const swUrl = `${process.env.PUBLIC_URL}/service-worker.js`;

      if (isLocalhost) {
        // This is running on localhost. Let's check if a service worker already exists.
        checkValidServiceWorker(swUrl, config);

        // Add some additional logging for localhost development.
        navigator.serviceWorker.ready.then(() => {
          // eslint-disable-next-line no-console
          console.log(
            'This web app is being served cache-first by a service worker. ' +
              'To learn more, visit https://cra.link/PWA',
          );
        });
      } else {
        // Is not localhost. Just register service worker.
        registerValidSW(swUrl, config);
      }
    });
  }
}

/**
 * Registers a valid service worker.
 * @param {string} swUrl - The URL of the service worker script.
 * @param {object} [config] - Optional configuration object.
 */
function registerValidSW(swUrl, config) {
  navigator.serviceWorker
    .register(swUrl)
    .then((registration) => {
      // Event listener for when an update is found.
      registration.onupdatefound = () => {
        const installingWorker = registration.installing;
        if (installingWorker == null) {
          return;
        }
        // Event listener for changes in the installing worker's state.
        installingWorker.onstatechange = () => {
          if (installingWorker.state === 'installed') {
            if (navigator.serviceWorker.controller) {
              // At this point, the updated precached content has been fetched,
              // but the previous service worker will still serve the older
              // content until all client tabs are closed.
              // eslint-disable-next-line no-console
              console.log(
                'New content is available and will be used when all ' +
                  'tabs for this page are closed. See https://cra.link/PWA.',
              );

              // Execute the onUpdate callback if provided in the config.
              if (config && config.onUpdate) {
                config.onUpdate(registration);
              }
            } else {
              // At this point, everything has been precached.
              // It's the first visit, so there is no prior service worker.
              // eslint-disable-next-line no-console
              console.log('Content is cached for offline use.');

              // Execute the onSuccess callback if provided in the config.
              if (config && config.onSuccess) {
                config.onSuccess(registration);
              }
            }
          }
        };
      };
    })
    .catch((error) => {
      // eslint-disable-next-line no-console
      console.error('Error during service worker registration:', error);
    });
}

/**
 * Checks if the service worker at the given URL is valid.
 * This is primarily for development on localhost to ensure it's not serving stale content.
 * @param {string} swUrl - The URL of the service worker script.
 * @param {object} [config] - Optional configuration object.
 */
function checkValidServiceWorker(swUrl, config) {
  // Try to download the service worker file.
  fetch(swUrl, {
    headers: { 'Service-Worker': 'script' }, // Indicate that this is a service worker request
  })
    .then((response) => {
      // Ensure service worker exists, and that it is a JS file.
      const contentType = response.headers.get('content-type');
      if (
        response.status === 404 ||
        (contentType != null && contentType.indexOf('javascript') === -1)
      ) {
        // No service worker found. Probably a different app is being served.
        // Unregister current service worker and reload the page.
        navigator.serviceWorker.ready.then((registration) => {
          registration.unregister().then(() => {
            window.location.reload();
          });
        });
      } else {
        // Service worker found. Proceed to register it.
        registerValidSW(swUrl, config);
      }
    })
    .catch(() => {
      // eslint-disable-next-line no-console
      console.log(
        'No internet connection found. App is running in offline mode.',
      );
    });
}

/**
 * Unregisters the currently active service worker.
 */
export function unregister() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready
      .then((registration) => {
        registration.unregister();
      })
      .catch((error) => {
        // eslint-disable-next-line no-console
        console.error(error.message);
      });
  }
}
