// src/utils/dateUtils.js
// Provides utility functions for common date calculations,
// primarily used in calendar or date-related components.

/**
 * Calculates the number of days in a given month of a specific year.
 * @param {number} year - The full year (e.g., 2024).
 * @param {number} month - The month index (0 for January, 11 for December).
 * @returns {number} The number of days in the specified month.
 */
export const getDaysInMonth = (year, month) => {
  // Setting day to 0 returns the last day of the previous month.
  // So, month + 1 and day 0 gives the last day of the target month.
  return new Date(year, month + 1, 0).getDate();
};

/**
 * Calculates the offset of the first day of a month (0 for Sunday, 6 for Saturday).
 * @param {number} year - The full year.
 * @param {number} month - The month index (0-11).
 * @returns {number} The day of the week (0-6) for the first day of the month.
 */
export const getFirstDayOffset = (year, month) => {
  // Creating a Date object for the first day of the month and getting its day of the week.
  return new Date(year, month, 1).getDay();
};

/**
 * Formats a Date object or ISO string into a "YYYY-MM-DD" string.
 * @param {Date | string} dateInput - The date object or ISO string to format.
 * @returns {string} The date formatted as "YYYY-MM-DD".
 */
export const formatDateToYYYYMMDD = (dateInput) => {
  const date = new Date(dateInput);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

/**
 * Formats a Date object or ISO string into a "YYYY-MM-DDTHH:MM" string for datetime-local input.
 * @param {Date | string} dateInput - The date object or ISO string to format.
 * @returns {string} The date formatted for datetime-local input.
 */
export const formatDateTimeLocal = (dateInput) => {
  const date = new Date(dateInput);
  // Adjust for timezone offset to prevent date shifting in datetime-local input
  date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
  return date.toISOString().slice(0, 16);
};
