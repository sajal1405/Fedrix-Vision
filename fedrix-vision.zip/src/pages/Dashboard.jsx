// src/pages/Dashboard.jsx
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  FaInfoCircle,
  FaTasks,
  FaUsers,
  FaCalendarAlt,
  FaProjectDiagram,
  FaFileAlt,
  FaUsersCog,
  FaEnvelopeOpenText, // Icon for messages/activity
} from 'react-icons/fa';
import PropTypes from 'prop-types';
import { useAuth } from '../context/AuthContext';
import { useUserProfile } from '../context/UserProfileContext';
import { supabase } from '../supabaseClient';

// Generic Dashboard Widget Component
const DashboardWidget = ({
  title,
  children,
  icon: Icon, // Icon displayed on the right for decorative purposes
  delay = 0,
  className = '',
  headerIcon: HeaderIcon, // Icon displayed in the header of the widget
  headerIconClass = 'text-teal-400',
  titleClass = 'text-white',
}) => (
  <motion.div
    className={`bg-dark-gray/60 p-6 rounded-xl shadow-lg border border-mid-gray ${className}`}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: delay }}
  >
    <div className="flex items-center justify-between mb-4">
      <h3 className={`text-xl font-semibold ${titleClass}`}>
        {HeaderIcon && <HeaderIcon className={`inline-block mr-3 text-2xl ${headerIconClass}`} />}
        {title}
      </h3>
      {Icon && <Icon className="text-3xl text-light-gray opacity-40" />}
    </div>
    {children}
  </motion.div>
);

DashboardWidget.propTypes = {
  title: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired,
  icon: PropTypes.elementType,
  delay: PropTypes.number,
  className: PropTypes.string,
  headerIcon: PropTypes.elementType,
  headerIconClass: PropTypes.string,
  titleClass: PropTypes.string,
};

const DashboardPage = () => {
  const { currentUser, isLoading: authLoading } = useAuth();
  const { userProfile, isLoadingProfile, profileError, fetchUserProfile } = useUserProfile();

  const [dashboardData, setDashboardData] = useState({
    totalProjects: '0',
    completedTasks: '0',
    activeUsers: '0',
    upcomingEvents: '0',
    recentActivities: [],
    recentPosts: [], // Renamed from recentProjects to recentPosts
  });
  const [dataError, setDataError] = useState(null);

  useEffect(() => {
    if (currentUser?.id) {
      fetchUserProfile(currentUser.id);
    }
  }, [currentUser?.id, fetchUserProfile]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setDataError(null);
      try {
        let totalProjectsCount = 0;
        let completedTasksCount = 0;
        let activeUsersCount = 0;
        let upcomingEventsCount = 0;
        let recentActivitiesList = [];
        let recentPostsList = [];

        // --- Fetch Total Posts (using 'posts' as proxy for 'projects') ---
        const { count: postsCount, data: postsData, error: postsError } = await supabase
          .from('posts') // Using 'posts' table
          .select('id, title, created_at', { count: 'exact' }) // Assuming 'title' and 'created_at'
          .order('created_at', { ascending: false })
          .limit(5);
        if (postsError) console.warn("Error fetching posts count:", postsError.message);
        totalProjectsCount = postsCount || 0;
        recentPostsList = postsData || [];

        // --- Fetch Completed Tasks for the current user ---
        const { count: tasksCount, error: tasksError } = await supabase
          .from('tasks')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', currentUser?.id)
          .eq('status', 'completed'); // Assuming 'completed' status
        if (tasksError) console.warn("Error fetching completed tasks count:", tasksError.message);
        completedTasksCount = tasksCount || 0;

        // --- Fetch Active Users (count from the 'profiles' table) ---
        const { count: usersCount, error: usersError } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true });
        if (usersError) console.warn("Error fetching active users count:", usersError.message);
        activeUsersCount = usersCount || 0;

        // --- Fetch Upcoming Events (combining various sources dynamically) ---
        const now = new Date();
        const nowIso = now.toISOString();
        const fortyEightHoursFromNowIso = new Date(now.getTime() + 48 * 60 * 60 * 1000).toISOString();
        
        let dynamicUpcomingEvents = 0;

        // 1. Tasks with a due_date (if tasks table has due_date)
        // If your tasks table has a 'due_date' column, uncomment and modify:
        const { count: upcomingTasksCount, error: upcomingTasksError } = await supabase
          .from('tasks')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', currentUser?.id)
          .not('due_date', 'is', null) // Ensure due_date is not null
          .gte('due_date', nowIso);
        if (upcomingTasksError) console.warn("Error fetching upcoming tasks:", upcomingTasksError.message);
        dynamicUpcomingEvents += (upcomingTasksCount || 0);

        // 2. Scheduled Posts (Social Media Calendar) in next 48 hours
        const { count: scheduledPostsCount, error: scheduledPostsError } = await supabase
          .from('scheduled_posts')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', currentUser?.id)
          .gte('scheduled_at', nowIso)
          .lt('scheduled_at', fortyEightHoursFromNowIso);
        if (scheduledPostsError) console.warn("Error fetching scheduled posts:", scheduledPostsError.message);
        dynamicUpcomingEvents += (scheduledPostsCount || 0);

        // 3. Reminders
        const { count: remindersCount, error: remindersError } = await supabase
          .from('reminders')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', currentUser?.id)
          .gte('reminder_time', nowIso);
        if (remindersError) console.warn("Error fetching reminders:", remindersError.message);
        dynamicUpcomingEvents += (remindersCount || 0);

        // 4. Calendar Events
        const { count: eventsCount, error: eventsError } = await supabase
          .from('events')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', currentUser?.id)
          .gte('event_date', nowIso);
        if (eventsError) console.warn("Error fetching calendar events:", eventsError.message);
        dynamicUpcomingEvents += (eventsCount || 0);

        // --- Fetch Recent Activities (using 'messages' as proxy) ---
        // Ideally, you'd have an 'activity_log' table with 'user_id', 'description', 'timestamp'
        const { data: recentMessages, error: messagesError } = await supabase
          .from('messages') // Using 'messages' table as a proxy for activity
          .select('content, created_at') // Assuming 'content' and 'created_at' columns
          .eq('sender_id', currentUser?.id) // Filter by current user's sent messages
          .order('created_at', { ascending: false })
          .limit(5);
        if (messagesError) console.warn("Error fetching recent messages (activity proxy):", messagesError.message);
        recentActivitiesList = (recentMessages || []).map(msg => ({
          description: `Sent message: "${msg.content.substring(0, 30)}${msg.content.length > 30 ? '...' : ''}"`,
          timestamp: msg.created_at,
        }));


        setDashboardData({
          totalProjects: totalProjectsCount,
          completedTasks: completedTasksCount,
          activeUsers: activeUsersCount,
          upcomingEvents: dynamicUpcomingEvents,
          recentActivities: recentActivitiesList,
          recentPosts: recentPostsList,
        });
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setDataError(err.message || 'Failed to load dashboard data.');
        setDashboardData(prev => ({
          ...prev,
          totalProjects: 'N/A',
          completedTasks: 'N/A',
          activeUsers: 'N/A',
          upcomingEvents: 'N/A',
          recentActivities: [],
          recentPosts: [],
        }));
      }
    };

    if (!authLoading && currentUser) {
      fetchDashboardData();
    }
  }, [authLoading, currentUser, userProfile]);

  if (authLoading || isLoadingProfile) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-160px)] text-off-white">
        <motion.svg
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
          className="h-8 w-8 mr-2 text-teal-400"
          viewBox="0 0 24 24"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          ></circle>
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          ></path>
        </motion.svg>
        <p className="mt-4">Loading dashboard...</p>
      </div>
    );
  }

  if (profileError || dataError) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-160px)] text-red-400">
        <p>Error: {profileError?.message || dataError}</p>
      </div>
    );
  }

  if (!userProfile) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-160px)] text-white/60">
        <p>No user profile available. Please try logging in again.</p>
      </div>
    );
  }

  const isSuperAdmin = userProfile?.role === 'admin'; // Dynamically detects if the user is a 'super admin'

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto p-4 md:p-8"
    >
      {/* Dynamic Grid for Dashboard Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
        {/* Project Overview Widget (using 'posts' as proxy) */}
        <DashboardWidget
          title="Content Overview" // Changed title to reflect 'posts'
          headerIcon={FaProjectDiagram}
          delay={0.1}
          className="col-span-1"
        >
          <p className="text-4xl font-bold text-teal-400 mb-2">{dashboardData.totalProjects}</p>
          <p className="text-sm text-light-gray">Total content items created</p>
          {dashboardData.recentPosts.length > 0 && (
            <div className="mt-4">
              <h4 className="text-md font-semibold text-white/80 mb-2">Recent Posts:</h4>
              <ul className="space-y-1 text-sm text-white/70">
                {dashboardData.recentPosts.map((post) => (
                  <li key={post.id} className="flex items-center">
                    <FaFileAlt className="mr-2 text-blue-400" />
                    {post.title}
                    <span className="ml-auto text-xs text-light-gray">
                      {new Date(post.created_at).toLocaleDateString()}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </DashboardWidget>

        {/* Task Summary Widget */}
        <DashboardWidget
          title="Task Summary"
          headerIcon={FaTasks}
          delay={0.2}
          className="col-span-1"
          headerIconClass="text-purple-400"
        >
          <p className="text-4xl font-bold text-purple-400 mb-2">{dashboardData.completedTasks}</p>
          <p className="text-sm text-light-gray">Tasks completed by you</p>
          <div className="mt-4 text-sm text-white/70">
            <p>Keep up the great work!</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-3 px-4 py-2 bg-purple-700 text-white rounded-md text-xs font-semibold hover:bg-purple-800 transition-colors"
            >
              View All Tasks
            </motion.button>
          </div>
        </DashboardWidget>

        {/* Upcoming Events Widget */}
        <DashboardWidget
          title="Upcoming Events"
          headerIcon={FaCalendarAlt}
          delay={0.3}
          className="col-span-1"
          headerIconClass="text-orange-400"
        >
          <p className="text-4xl font-bold text-orange-400 mb-2">{dashboardData.upcomingEvents}</p>
          <p className="text-sm text-light-gray">Total events & deadlines</p>
          <div className="mt-4 text-sm text-white/70">
            <p>Stay on top of your schedule.</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-3 px-4 py-2 bg-orange-700 text-white rounded-md text-xs font-semibold hover:bg-orange-800 transition-colors"
            >
              View Calendar
            </motion.button>
          </div>
        </DashboardWidget>

        {/* Recent Activity Widget (using 'messages' as proxy) */}
        <DashboardWidget
          title="Recent Activity"
          headerIcon={FaEnvelopeOpenText} // Changed icon to represent messages/activity
          delay={0.4}
          className="md:col-span-2 lg:col-span-1"
          headerIconClass="text-green-400"
        >
          <ul className="space-y-3 text-white/80">
            {dashboardData.recentActivities.length > 0 ? (
              dashboardData.recentActivities.map((activity, index) => (
                <li key={index} className="flex items-center text-sm">
                  <span className="flex-shrink-0 mr-3 text-green-400">●</span>
                  {activity.description}
                  {activity.timestamp && (
                    <span className="ml-auto text-xs text-light-gray">
                      {new Date(activity.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                </li>
              ))
            ) : (
              <li className="text-sm text-white/60">No recent activity.</li>
            )}
          </ul>
        </DashboardWidget>

        {/* Admin Insights Widget (conditionally rendered for super admin) */}
        {isSuperAdmin && (
          <DashboardWidget
            title="Admin Insights"
            headerIcon={FaUsersCog}
            delay={0.5}
            className="md:col-span-2 lg:col-span-2 col-span-full bg-red-800/60 border-red-500"
            headerIconClass="text-red-300"
            titleClass="text-red-100"
          >
            <p className="text-4xl font-bold text-red-300 mb-2">{dashboardData.activeUsers}</p>
            <p className="text-sm text-red-200">Total active users on the platform.</p>
            <div className="mt-4 text-sm text-red-200">
              <p>This section provides critical administrative data and controls.</p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="mt-3 px-4 py-2 bg-red-700 text-white rounded-md text-xs font-semibold hover:bg-red-800 transition-colors"
              >
                Manage Users
              </motion.button>
            </div>
          </DashboardWidget>
        )}

        {/* Placeholder for future widgets */}
        <DashboardWidget
          title="New Modules"
          delay={0.6}
          className="col-span-1"
          headerIcon={FaInfoCircle}
          headerIconClass="text-gray-400"
        >
          <p className="text-sm text-light-gray">Discover powerful new integrations and features here!</p>
          <div className="mt-4 text-sm text-white/70">
            <p>We are constantly expanding our capabilities.</p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-3 px-4 py-2 bg-gray-700 text-white rounded-md text-xs font-semibold hover:bg-gray-800 transition-colors"
            >
              Explore Features
            </motion.button>
          </div>
        </DashboardWidget>
      </div>
    </motion.div>
  );
};

export default DashboardPage;
