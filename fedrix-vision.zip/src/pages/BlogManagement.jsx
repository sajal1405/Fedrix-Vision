// src/pages/BlogManagement.jsx
import React from 'react';
import BlogManager from '../components/blog/BlogManager';
import { motion } from 'framer-motion';
// import { useContext } from 'react'; // Removed unused useContext

const BlogManagement = () => {
  return (
    <motion.div
      className="dashboard p-6 animate-fade-in flex flex-col h-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <BlogManager />
    </motion.div>
  );
};

export default BlogManagement;
