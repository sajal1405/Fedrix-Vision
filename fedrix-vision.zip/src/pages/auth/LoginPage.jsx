// src/pages/auth/LoginPage.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import LoginForm from '../../components/auth/LoginForm';
import AnimatedBackground from '../../components/common/AnimatedBackground'; // Ensure this path is correct

const LoginPage = () => {
  const navigate = useNavigate();

  const handleLoginSuccess = () => {
    console.log('Login successful! Redirecting to dashboard.');
    navigate('/dashboard'); // Redirect to dashboard on successful login
  };

  const handleForgotPassword = () => {
    console.log('Navigating to Forgot Password page.');
    navigate('/forgot-password'); // Navigate to forgot password page
  };

  const handleRegister = () => {
    console.log('Navigating to Register page.');
    navigate('/register'); // Navigate to register page
  };

  return (
    // This outermost div ensures the entire page takes full screen height and centers its content
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full p-4 overflow-hidden">
      {/* Animated background positioned absolutely to cover the whole viewport */}
      <AnimatedBackground />

      {/* Main container for the login form, z-indexed to be above the background */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        // This div uses flexbox to center the LoginForm within the available space
        className="relative z-10 flex items-center justify-center h-full w-full"
      >
        <LoginForm
          onLoginSuccess={handleLoginSuccess}
          onForgotPassword={handleForgotPassword}
          onRegister={handleRegister}
        />
      </motion.div>
    </div>
  );
};

export default LoginPage;
