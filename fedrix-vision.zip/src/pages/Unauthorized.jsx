// src/pages/Unauthorized.jsx
// This component is displayed when a user attempts to access a route
// for which they do not have the required permissions based on their role.
import React from 'react';
import { motion } from 'framer-motion'; // For animations
import { Link } from 'react-router-dom'; // For navigation links
import { FaBan } from 'react-icons/fa'; // Icon for restricted access

const Unauthorized = () => {
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-screen text-center p-6 bg-dark"
      initial={{ opacity: 0, scale: 0.9 }} // Initial animation state
      animate={{ opacity: 1, scale: 1 }} // Animation to full opacity and scale
      transition={{ duration: 0.5 }} // Animation duration
    >
      <FaBan className="text-red-500 text-6xl mb-6 animate-pulse" />{' '}
      {/* Warning icon with pulse effect */}
      <h1 className="text-white text-4xl font-bold mb-4">Access Denied!</h1>
      <p className="text-white/70 text-lg mb-6 max-w-lg">
        You do not have the necessary permissions to view this page. Please
        contact your administrator if you believe this is an error.
      </p>
      {/* Link back to the dashboard */}
      <Link
        to="/dashboard"
        className="btn-action inline-flex items-center gap-2 px-8 py-3 text-lg"
      >
        Go to Dashboard
      </Link>
    </motion.div>
  );
};

export default Unauthorized;
