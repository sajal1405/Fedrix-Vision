// src/pages/Profile.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useProfile } from '../context/UserProfileContext';
import { motion } from 'framer-motion';
// FaUserCircle was imported but not used directly. FaEdit needs to be imported.
import {
  FaEnvelope,
  FaBuilding,
  FaInfoCircle,
  FaSpinner,
  FaEdit,
} from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Profile = () => {
  const { currentUser } = useAuth();
  const { profile, isLoadingProfile, refreshProfile } = useProfile();
  const [localProfile, setLocalProfile] = useState(null);

  // eslint-disable-next-line no-unused-vars
  const fetchProfileData = refreshProfile;

  useEffect(() => {
    if (profile) {
      setLocalProfile(profile);
    }
  }, [profile]);

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center h-full min-h-[300px]">
        <p className="text-light-gray text-lg">
          Please log in to view your profile.
        </p>
      </div>
    );
  }

  if (isLoadingProfile || !localProfile) {
    return (
      <div className="flex justify-center items-center h-full min-h-[300px]">
        <FaSpinner className="animate-spin text-teal-400 text-3xl" />
        <p className="ml-3 text-light-gray">Loading profile data...</p>
      </div>
    );
  }

  return (
    <motion.div
      className="dashboard p-6 animate-fade-in flex flex-col h-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-6 text-off-white">My Profile</h1>

      <motion.div
        className="glass-effect p-6 rounded-xl shadow-lg border border-mid-gray flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="flex-shrink-0">
          <img
            src={
              localProfile.avatar ||
              `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${currentUser.id}`
            }
            alt="User Avatar"
            className="w-32 h-32 rounded-full border-4 border-teal-400 object-cover shadow-lg"
            onError={(e) => {
              e.target.onerror = null;
              e.target.src =
                'https://placehold.co/128x128/333333/F5F5F5?text=AV';
            }}
          />
        </div>

        <div className="flex-grow text-center md:text-left">
          <h2 className="text-4xl font-bold text-off-white mb-2">
            {localProfile.full_name || 'No Name Provided'}
          </h2>
          <p className="text-teal-300 text-lg mb-4 capitalize">
            {localProfile.role || 'Role not set'}
          </p>

          <div className="space-y-3 text-light-gray">
            <p className="flex items-center justify-center md:justify-start">
              <FaEnvelope className="mr-3 text-xl text-mid-gray" />{' '}
              {localProfile.email}
            </p>
            {localProfile.company && (
              <p className="flex items-center justify-center md:justify-start">
                <FaBuilding className="mr-3 text-xl text-mid-gray" />{' '}
                {localProfile.company}
              </p>
            )}
            {localProfile.bio && (
              <p className="flex items-center justify-center md:justify-start">
                <FaInfoCircle className="mr-3 text-xl text-mid-gray" />{' '}
                {localProfile.bio}
              </p>
            )}
          </div>

          <Link
            to="/profile-settings"
            className="btn-action mt-6 inline-flex items-center"
          >
            <FaEdit className="mr-2" /> Edit Profile
          </Link>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Profile;
