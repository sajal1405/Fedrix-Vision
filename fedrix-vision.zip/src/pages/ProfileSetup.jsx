// src/pages/ProfileSetup.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useProfile } from '../context/UserProfileContext';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
// Removed unused FaUserCircle, FaBuilding, FaInfoCircle
import { FaSave, FaSpinner } from 'react-icons/fa';

const ProfileSetup = () => {
  const { currentUser, isAuthenticated } = useAuth();
  const { profile, isLoadingProfile, refreshProfile } = useProfile();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [company, setCompany] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  useEffect(() => {
    if (!isAuthenticated && !isLoadingProfile) {
      navigate('/login');
      return;
    }

    if (profile) {
      navigate('/dashboard');
    } else if (currentUser && !isLoadingProfile) {
      setFullName(currentUser.email?.split('@')[0] || '');
      setAvatarUrl(
        `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${currentUser.id}`,
      );
    }
  }, [isAuthenticated, isLoadingProfile, profile, currentUser, navigate]);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setMessage('');
    setMessageType('');

    if (!currentUser) {
      showMessage('No authenticated user found. Please login again.', 'error');
      setIsSaving(false);
      return;
    }

    try {
      const { error } = await window.supabase.from('profiles').insert([
        {
          id: currentUser.id,
          email: currentUser.email,
          full_name: fullName,
          company: company,
          bio: bio,
          avatar: avatarUrl,
          role: 'client',
        },
      ]);

      if (error) throw error;
      showMessage(
        'Profile setup complete! Redirecting to dashboard...',
        'success',
      );
      refreshProfile();
      setTimeout(() => navigate('/dashboard'), 1500);
    } catch (error) {
      console.error('Error saving profile:', error.message);
      showMessage(`Error saving profile: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isAuthenticated || isLoadingProfile) {
    return (
      <div className="flex justify-center items-center h-screen bg-black-ops text-off-white">
        <FaSpinner className="animate-spin text-teal-400 text-3xl" />
        <p className="ml-3 text-lg">Loading...</p>
      </div>
    );
  }

  return (
    <motion.div
      className="min-h-screen flex items-center justify-center p-4 bg-black-ops text-off-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        className="glass-effect p-8 rounded-xl shadow-lg max-w-lg w-full border border-mid-gray"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
      >
        <h2 className="text-3xl font-bold mb-8 text-center text-off-white">
          Complete Your Profile
        </h2>

        {message && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className={`p-3 mb-4 rounded-md text-sm ${
              messageType === 'success'
                ? 'bg-green-700/30 text-green-300 border border-green-500'
                : 'bg-red-700/30 text-red-300 border border-red-500'
            }`}
          >
            {message}
          </motion.div>
        )}

        <form onSubmit={handleSaveProfile}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label
                htmlFor="fullName"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Full Name:
              </label>
              <input
                type="text"
                id="fullName"
                className="email-input"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                disabled={isSaving}
              />
            </div>
            <div>
              <label
                htmlFor="email"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Email:
              </label>
              <input
                type="email"
                id="email"
                className="email-input bg-mid-gray cursor-not-allowed"
                value={currentUser?.email || ''}
                disabled
              />
            </div>
            <div>
              <label
                htmlFor="company"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Company (Optional):
              </label>
              <input
                type="text"
                id="company"
                className="email-input"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                disabled={isSaving}
              />
            </div>
            <div>
              <label
                htmlFor="avatarUrl"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Avatar URL (Optional):
              </label>
              <input
                type="url"
                id="avatarUrl"
                className="email-input"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="e.g., https://example.com/your-avatar.jpg"
                disabled={isSaving}
              />
              {avatarUrl && (
                <img
                  src={avatarUrl}
                  alt="Avatar Preview"
                  className="w-20 h-20 rounded-full object-cover mt-2 border border-mid-gray"
                />
              )}
            </div>
            <div className="md:col-span-2">
              <label
                htmlFor="bio"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Bio (Optional):
              </label>
              <textarea
                id="bio"
                className="email-input min-h-[100px]"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                disabled={isSaving}
              ></textarea>
            </div>
          </div>
          <button
            type="submit"
            className="btn-action w-full flex items-center justify-center gap-2"
            disabled={isSaving || !fullName}
          >
            {isSaving ? <FaSpinner className="animate-spin" /> : <FaSave />}{' '}
            Save Profile
          </button>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default ProfileSetup;
