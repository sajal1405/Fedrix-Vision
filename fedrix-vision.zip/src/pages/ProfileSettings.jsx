// src/pages/ProfileSettings.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useUserProfile } from '../context/UserProfileContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FaEdit,
  FaSave,
  FaTimes,
  FaCamera,
  FaTrashAlt,
  FaLock,
  FaUser,
  FaPhone,
  FaBuilding,
  FaPalette,
  FaCalendarAlt,
  FaAddressBook,
  FaBriefcase,
  FaIdCard,
  FaBell,
  FaUserCog,
} from 'react-icons/fa';
import PropTypes from 'prop-types';
import { supabase } from '../supabaseClient';

// Reusable EditableField Component
const EditableField = ({
  label,
  value,
  type = 'text',
  onChange,
  isEditing,
  disabled = false,
  icon: Icon,
  required = false,
  options = [],
}) => {
  const isDate = type === 'date';
  const displayValue =
    isDate && value
      ? new Date(value).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        })
      : value || 'N/A';
  const inputValue = isDate && value ? value.split('T')[0] : value || '';

  const inputId = `input-${label.toLowerCase().replace(/\s/g, '-')}`;

  return (
    <div className="relative mb-4">
      <label
        htmlFor={inputId}
        className="block text-light-gray text-sm font-bold mb-2"
      >
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {isEditing && !disabled ? (
        type === 'textarea' ? (
          <textarea
            id={inputId}
            value={inputValue}
            onChange={onChange}
            className="shadow appearance-none border border-mid-gray rounded-lg w-full py-3 px-4 bg-dark-gray/60 text-white leading-tight focus:outline-none focus:shadow-outline focus:border-teal-500 h-24 resize-y"
            required={required}
          />
        ) : type === 'select' ? (
          <select
            id={inputId}
            value={inputValue}
            onChange={onChange}
            className="shadow appearance-none border border-mid-gray rounded-lg w-full py-3 px-4 bg-dark-gray/60 text-white leading-tight focus:outline-none focus:shadow-outline focus:border-teal-500"
            required={required}
          >
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        ) : (
          <input
            id={inputId}
            type={type}
            value={inputValue}
            onChange={onChange}
            className="shadow appearance-none border border-mid-gray rounded-lg w-full py-3 px-4 bg-dark-gray/60 text-white leading-tight focus:outline-none focus:shadow-outline focus:border-teal-500"
            required={required}
          />
        )
      ) : (
        <div className="shadow appearance-none border border-mid-gray rounded-lg w-full py-3 px-4 bg-dark-gray/30 text-white/80 leading-tight flex items-center justify-between">
          <span>{displayValue}</span>
          {Icon && <Icon className="text-white/60 ml-2" />}
          {disabled && (
            <FaLock className="text-white/40 ml-2" title="Not editable" />
          )}
        </div>
      )}
    </div>
  );
};

EditableField.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.any,
  type: PropTypes.string,
  onChange: PropTypes.func.isRequired,
  isEditing: PropTypes.bool.isRequired,
  disabled: PropTypes.bool,
  icon: PropTypes.elementType,
  required: PropTypes.bool,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
    }),
  ),
};

const ProfileSettings = () => {
  const { currentUser } = useAuth();
  const { userProfile, isLoadingProfile, profileError, updateUserProfile } =
    useUserProfile();

  const [editableProfile, setEditableProfile] = useState({});
  const [isEditingSection, setIsEditingSection] = useState({
    personal: false,
    contact: false,
    professional: false,
    preferences: false,
    role: false,
  });
  // eslint-disable-next-line no-unused-vars
  const [sectionErrors, setSectionErrors] = useState({});
  // eslint-disable-next-line no-unused-vars
  const [hasValidationError, setHasValidationError] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState({ success: false, error: null });

  useEffect(() => {
    if (userProfile) {
      setEditableProfile(userProfile);
      setIsEditingSection({
        personal: false,
        contact: false,
        professional: false,
        preferences: false,
        role: false,
      });
      setSectionErrors({});
      setSaveStatus({ success: false, error: null });
    }
  }, [userProfile]);

  const handleChange = (section, field, value) => {
    setEditableProfile((prev) => ({
      ...prev,
      [field]: value,
    }));
    setSectionErrors((prev) => {
      const newSectionErrors = { ...prev };
      if (newSectionErrors[section]) {
        delete newSectionErrors[section][field];
        if (Object.keys(newSectionErrors[section]).length === 0) {
          delete newSectionErrors[section];
        }
      }
      return newSectionErrors;
    });
    setSaveStatus({ success: false, error: null });
  };

  const handleEditClick = (section) => {
    setIsEditingSection((prev) => ({ ...prev, [section]: true }));
    setSaveStatus({ success: false, error: null });
    setSectionErrors({});
  };

  const handleCancelClick = (section) => {
    setIsEditingSection((prev) => ({ ...prev, [section]: false }));
    setEditableProfile(userProfile);
    setSectionErrors({});
    setSaveStatus({ success: false, error: null });
  };

  const handleSaveClick = async (section) => {
    const currentSectionErrors = {};
    // eslint-disable-next-line no-unused-vars
    let tempHasValidationError = false;

    const requiredFields = {
      personal: ['full_name'],
      contact: ['phone_number', 'address', 'city', 'country'],
      professional: ['job_title', 'company'],
      preferences: [],
      role: ['role'],
    };

    requiredFields[section]?.forEach((field) => {
      if (
        field === 'notification_preferences' &&
        typeof editableProfile[field] === 'string'
      ) {
        try {
          JSON.parse(editableProfile[field]);
        } catch (e) {
          currentSectionErrors[field] = 'Invalid JSON format.';
          tempHasValidationError = true;
        }
      } else if (
        !editableProfile[field] ||
        (typeof editableProfile[field] === 'string' &&
          editableProfile[field].trim() === '')
      ) {
        currentSectionErrors[field] =
          `${field.replace(/_/g, ' ')} is required.`;
        tempHasValidationError = true;
      }
    });

    if (Object.keys(currentSectionErrors).length > 0) {
      setSectionErrors((prev) => ({
        ...prev,
        [section]: currentSectionErrors,
      }));
      setSaveStatus({
        success: false,
        error: 'Please fill in all required fields correctly.',
      });
      return;
    }

    setIsSaving(true);
    setSaveStatus({ success: false, error: null });

    try {
      const updates = {};
      switch (section) {
        case 'personal':
          updates.full_name = editableProfile.full_name;
          updates.date_of_birth = editableProfile.date_of_birth;
          updates.gender = editableProfile.gender;
          break;
        case 'contact':
          updates.phone_number = editableProfile.phone_number;
          updates.address = editableProfile.address;
          updates.city = editableProfile.city;
          updates.state_province = editableProfile.state_province;
          updates.postal_code = editableProfile.postal_code;
          updates.country = editableProfile.country;
          break;
        case 'professional':
          updates.job_title = editableProfile.job_title;
          updates.department = editableProfile.department;
          updates.company = editableProfile.company;
          updates.employee_id = editableProfile.employee_id;
          updates.start_date = editableProfile.start_date;
          break;
        case 'preferences':
          updates.notification_preferences =
            typeof editableProfile.notification_preferences === 'string'
              ? JSON.parse(editableProfile.notification_preferences)
              : editableProfile.notification_preferences;
          updates.theme_preference = editableProfile.theme_preference;
          break;
        case 'role':
          updates.role = editableProfile.role;
          break;
        default:
          break;
      }

      const { success, error } = await updateUserProfile(updates);

      if (!success) {
        throw error;
      }

      setSaveStatus({ success: true, error: null });
      setIsEditingSection((prev) => ({ ...prev, [section]: false }));
    } catch (err) {
      console.error('Failed to save profile:', err);
      setSaveStatus({
        success: false,
        error: `Failed to save changes: ${err.message || 'Unknown error'}`,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleAvatarChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsSaving(true);
    setSaveStatus({ success: false, error: null });

    const fileExtension = file.name.split('.').pop();
    const filePath = `${currentUser.id}/${Date.now()}.${fileExtension}`;

    try {
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: true,
        });

      if (uploadError) throw uploadError;

      const { data: publicUrlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(uploadData.path);

      if (!publicUrlData || !publicUrlData.publicUrl) {
        throw new Error('Could not get public URL for uploaded avatar.');
      }

      const { success, error } = await updateUserProfile({
        avatar_url: publicUrlData.publicUrl,
      });
      if (!success) {
        throw error;
      }

      setSaveStatus({ success: true, error: null });
    } catch (err) {
      console.error('Error updating avatar:', err);
      setSaveStatus({
        success: false,
        error: `Failed to update avatar: ${err.message || 'Unknown error'}`,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAvatar = async () => {
    if (
      !userProfile?.avatar_url ||
      userProfile.avatar_url.includes('placehold.co')
    ) {
      alert('No custom avatar to delete.');
      return;
    }
    if (!window.confirm('Are you sure you want to delete your avatar?')) {
      return;
    }

    setIsSaving(true);
    setSaveStatus({ success: false, error: null });

    try {
      const urlParts = userProfile.avatar_url.split('/public/');
      if (urlParts.length < 2) {
        throw new Error('Invalid avatar URL for deletion.');
      }
      const filePathToDelete = urlParts[1];

      const { error: deleteError } = await supabase.storage
        .from('avatars')
        .remove([filePathToDelete]);

      if (deleteError) throw deleteError;

      const { success, error: updateProfileError } = await updateUserProfile({
        avatar_url: null,
      });
      if (!success) {
        throw updateProfileError;
      }

      setSaveStatus({ success: true, error: null });
    } catch (err) {
      console.error('Error deleting avatar:', err);
      setSaveStatus({
        success: false,
        error: `Failed to delete avatar: ${err.message || 'Unknown error'}`,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const renderSectionHeader = (sectionName, sectionKey) => {
    const isEditing = isEditingSection[sectionKey];
    const userRole = userProfile?.role;

    const canEditSection =
      (userRole === 'admin' || userRole === 'user') && sectionKey !== 'role';
    const canEditRoleSection = userRole === 'admin';

    const showEditButton =
      (sectionKey === 'role' && canEditRoleSection) ||
      (sectionKey !== 'role' && canEditSection);

    return (
      <div className="flex items-center justify-between mb-4 border-b border-mid-gray pb-2">
        <h3 className="text-xl font-semibold text-white">{sectionName}</h3>
        <div>
          {isEditing ? (
            <>
              <motion.button
                onClick={() => handleSaveClick(sectionKey)}
                className="btn-primary mr-2 flex items-center px-4 py-2 rounded-md transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isSaving}
              >
                <FaSave className="mr-2" /> {isSaving ? 'Saving...' : 'Save'}
              </motion.button>
              <motion.button
                onClick={() => handleCancelClick(sectionKey)}
                className="btn-secondary flex items-center px-4 py-2 rounded-md transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isSaving}
              >
                <FaTimes className="mr-2" /> Cancel
              </motion.button>
            </>
          ) : (
            showEditButton && (
              <motion.button
                onClick={() => handleEditClick(sectionKey)}
                className="btn-action flex items-center px-4 py-2 rounded-md transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isSaving}
              >
                <FaEdit className="mr-2" /> Edit
              </motion.button>
            )
          )}
        </div>
      </div>
    );
  };

  if (isLoadingProfile) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen-content text-off-white">
        <motion.svg
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
          className="h-8 w-8 mr-2 text-teal-400"
          viewBox="0 0 24 24"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          ></circle>
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          ></path>
        </motion.svg>
        <p className="mt-4">Loading user profile...</p>
      </div>
    );
  }

  if (profileError) {
    return (
      <div className="flex items-center justify-center min-h-screen-content text-red-400">
        <p>Error loading profile: {profileError.message}</p>
      </div>
    );
  }

  if (!userProfile) {
    return (
      <div className="flex items-center justify-center min-h-screen-content text-white/60">
        <p>No user profile available. Please try logging in again.</p>
      </div>
    );
  }

  const { avatar_url, full_name, job_title } = editableProfile;

  const currentAvatar =
    avatar_url || 'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR';

  const isFieldRestricted = (fieldKey) => {
    if (
      userProfile?.role !== 'admin' &&
      (fieldKey === 'role' || fieldKey === 'employee_id')
    ) {
      return true;
    }
    return false;
  };

  const genderOptions = [
    { value: '', label: 'Select Gender' },
    { value: 'male', label: 'Male' },
    { value: 'female', label: 'Female' },
    { value: 'non-binary', label: 'Non-Binary' },
    { value: 'prefer-not-to-say', label: 'Prefer not to say' },
  ];

  const themeOptions = [
    { value: 'system', label: 'System Default' },
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto p-4 md:p-8"
    >
      <h2 className="text-3xl font-bold text-white mb-8 border-b border-teal-500 pb-4">
        Profile Settings
      </h2>

      <AnimatePresence>
        {saveStatus.success && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-green-600/40 border border-green-500 text-white p-3 rounded-md mb-4 text-center"
          >
            Profile updated successfully!
          </motion.div>
        )}
        {saveStatus.error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-red-600/40 border border-red-500 text-white p-3 rounded-md mb-4 text-center"
          >
            {saveStatus.error}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div
          className="lg:col-span-1 bg-dark-gray/60 p-6 rounded-xl shadow-lg border border-mid-gray flex flex-col items-center"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <img
            src={currentAvatar}
            alt="User Avatar"
            className="w-48 h-48 rounded-full object-cover border-4 border-teal-500 shadow-md mb-6"
            onError={(e) => {
              e.target.onerror = null;
              e.target.src =
                'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR';
            }}
          />
          <h3 className="text-2xl font-bold text-white mb-2">
            {full_name || 'New User'}
          </h3>
          <p className="text-teal-400 text-lg mb-6">
            {job_title || 'Unassigned'}
          </p>

          <input
            type="file"
            id="avatar-upload"
            className="hidden"
            accept="image/*"
            onChange={handleAvatarChange}
            disabled={isSaving}
          />
          <label
            htmlFor="avatar-upload"
            className={`btn-primary flex items-center justify-center w-full max-w-xs cursor-pointer mb-2
                        ${isSaving ? 'opacity-50 cursor-not-allowed' : 'hover:bg-teal-700'}`}
          >
            <FaCamera className="mr-2" />{' '}
            {isSaving ? 'Uploading...' : 'Change Avatar'}
          </label>
          <motion.button
            onClick={handleDeleteAvatar}
            className="btn-secondary flex items-center justify-center w-full max-w-xs"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            disabled={isSaving || currentAvatar.includes('placehold.co')}
          >
            <FaTrashAlt className="mr-2" /> Delete Avatar
          </motion.button>
        </motion.div>

        <div className="lg:col-span-2 space-y-8">
          <motion.div
            className="bg-dark-gray/60 p-6 rounded-xl shadow-lg border border-mid-gray"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {renderSectionHeader('Personal Information', 'personal')}
            <EditableField
              label="Full Name"
              value={editableProfile.full_name}
              onChange={(e) =>
                handleChange('personal', 'full_name', e.target.value)
              }
              isEditing={isEditingSection.personal}
              required={true}
              icon={FaUser}
            />
            <EditableField
              label="Date of Birth"
              value={editableProfile.date_of_birth}
              type="date"
              onChange={(e) =>
                handleChange('personal', 'date_of_birth', e.target.value)
              }
              isEditing={isEditingSection.personal}
              icon={FaCalendarAlt}
            />
            <EditableField
              label="Gender"
              value={editableProfile.gender}
              type="select"
              onChange={(e) =>
                handleChange('personal', 'gender', e.target.value)
              }
              isEditing={isEditingSection.personal}
              options={genderOptions}
              icon={FaUser}
            />
          </motion.div>

          <motion.div
            className="bg-dark-gray/60 p-6 rounded-xl shadow-lg border border-mid-gray"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            {renderSectionHeader('Contact Details', 'contact')}
            <EditableField
              label="Phone Number"
              value={editableProfile.phone_number}
              type="tel"
              onChange={(e) =>
                handleChange('contact', 'phone_number', e.target.value)
              }
              isEditing={isEditingSection.contact}
              required={true}
              icon={FaPhone}
            />
            <EditableField
              label="Address"
              value={editableProfile.address}
              onChange={(e) =>
                handleChange('contact', 'address', e.target.value)
              }
              isEditing={isEditingSection.contact}
              icon={FaAddressBook}
              type="textarea"
            />
            <EditableField
              label="City"
              value={editableProfile.city}
              onChange={(e) => handleChange('contact', 'city', e.target.value)}
              isEditing={isEditingSection.contact}
              required={true}
            />
            <EditableField
              label="State/Province"
              value={editableProfile.state_province}
              onChange={(e) =>
                handleChange('contact', 'state_province', e.target.value)
              }
              isEditing={isEditingSection.contact}
            />
            <EditableField
              label="Postal Code"
              value={editableProfile.postal_code}
              onChange={(e) =>
                handleChange('contact', 'postal_code', e.target.value)
              }
              isEditing={isEditingSection.contact}
            />
            <EditableField
              label="Country"
              value={editableProfile.country}
              onChange={(e) =>
                handleChange('contact', 'country', e.target.value)
              }
              isEditing={isEditingSection.contact}
              required={true}
            />
          </motion.div>

          <motion.div
            className="bg-dark-gray/60 p-6 rounded-xl shadow-lg border border-mid-gray"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            {renderSectionHeader('Professional Information', 'professional')}
            <EditableField
              label="Job Title"
              value={editableProfile.job_title}
              onChange={(e) =>
                handleChange('professional', 'job_title', e.target.value)
              }
              isEditing={isEditingSection.professional}
              required={true}
              icon={FaBriefcase}
            />
            <EditableField
              label="Department"
              value={editableProfile.department}
              onChange={(e) =>
                handleChange('professional', 'department', e.target.value)
              }
              isEditing={isEditingSection.professional}
              icon={FaBuilding}
            />
            <EditableField
              label="Company"
              value={editableProfile.company}
              onChange={(e) =>
                handleChange('professional', 'company', e.target.value)
              }
              isEditing={isEditingSection.professional}
              required={true}
              icon={FaBuilding}
            />
            <EditableField
              label="Employee ID"
              value={editableProfile.employee_id}
              onChange={(e) =>
                handleChange('professional', 'employee_id', e.target.value)
              }
              isEditing={isEditingSection.professional}
              disabled={isFieldRestricted('employee_id')}
              icon={FaIdCard}
            />
            <EditableField
              label="Start Date"
              value={editableProfile.start_date}
              type="date"
              onChange={(e) =>
                handleChange('professional', 'start_date', e.target.value)
              }
              isEditing={isEditingSection.professional}
              icon={FaCalendarAlt}
            />
          </motion.div>

          <motion.div
            className="bg-dark-gray/60 p-6 rounded-xl shadow-lg border border-mid-gray"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            {renderSectionHeader('Preferences', 'preferences')}
            <EditableField
              label="Theme Preference"
              value={editableProfile.theme_preference}
              type="select"
              onChange={(e) =>
                handleChange('preferences', 'theme_preference', e.target.value)
              }
              isEditing={isEditingSection.preferences}
              options={themeOptions}
              icon={FaPalette}
            />
            <EditableField
              label="Notification Preferences (JSON)"
              value={JSON.stringify(
                editableProfile.notification_preferences || {},
                null,
                2,
              )}
              onChange={(e) => {
                try {
                  handleChange(
                    'preferences',
                    'notification_preferences',
                    e.target.value ? JSON.parse(e.target.value) : {},
                  );
                } catch (err) {
                  setSaveStatus((prev) => ({
                    ...prev,
                    error:
                      'Invalid JSON format for Notification Preferences. Please correct it.',
                  }));
                }
              }}
              isEditing={isEditingSection.preferences}
              type="textarea"
              icon={FaBell}
            />
          </motion.div>

          {userProfile.role === 'admin' && (
            <motion.div
              className="bg-red-800/60 p-6 rounded-xl shadow-lg border border-red-500"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              {renderSectionHeader('User Role (Admin Only)', 'role')}
              <p className="text-red-200 text-sm mb-4">
                Changing roles is highly sensitive and typically requires
                backend validation (e.g., Supabase Edge Function or Cloud
                Function). This is for demonstration purposes.
              </p>
              <EditableField
                label="Role"
                value={editableProfile.role}
                type="text"
                onChange={(e) => handleChange('role', 'role', e.target.value)}
                isEditing={isEditingSection.role}
                disabled={isFieldRestricted('role') && !isEditingSection.role}
                icon={FaUserCog}
              />
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ProfileSettings;
