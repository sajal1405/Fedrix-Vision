// src/pages/Reminders.jsx
// This component acts as a wrapper page for the ReminderList component.
// It provides a consistent layout and title for the reminders section of the application.
import React from 'react';
import ReminderList from '../components/reminders/ReminderList.jsx'; // Import the ReminderList component
import { motion } from 'framer-motion'; // For page animations

const Reminders = () => (
  <motion.div
    className="p-6 bg-white/5 rounded-xl border border-white/10 shadow-lg min-h-[calc(100vh-180px)] flex flex-col"
    initial={{ opacity: 0, y: 10 }} // Initial animation state for the page container
    animate={{ opacity: 1, y: 0 }} // Animation to full opacity
    transition={{ duration: 0.5 }} // Animation duration
  >
    <h2 className="text-white text-2xl font-bold mb-4">🔔 Reminders</h2>
    {/* Render the ReminderList component, which handles all reminder logic and UI */}
    <ReminderList />
  </motion.div>
);

export default Reminders;
