// src/components/layout/Header.jsx
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useProfile } from '../../context/UserProfileContext'; // Import useProfile

const Header = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const { profile } = useProfile(); // Get profile from context

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
      alert('Failed to log out.');
    }
  };

  const displayName = profile?.full_name || currentUser?.email || 'User';
  const displayAvatar =
    profile?.avatar_url ||
    'https://via.placeholder.com/150/00bf8b/FFFFFF?text=FP'; // Default avatar

  return (
    <header className="fixed top-0 left-0 w-full bg-black-ops bg-opacity-80 backdrop-filter backdrop-blur-lg border-b border-white/10 z-30 shadow-lg p-4 flex justify-between items-center pr-10">
      <div className="flex items-center">
        {/* Logo/Brand Name */}
        <Link
          to="/dashboard"
          className="text-white text-2xl font-bold tracking-wider hover:text-teal-300 transition-colors duration-300"
        >
          Fedrix Vision
        </Link>
        {/* Welcome Message in Header - Ensure it's visible */}
        {currentUser && (
          <span className="ml-4 text-white/70 text-base sm:text-lg block">
            {' '}
            {/* 'block' ensures it's always rendered */}
            Welcome,{' '}
            <span className="font-semibold text-teal-300">
              {profile?.full_name || currentUser?.email.split('@')[0]}
            </span>
            !
          </span>
        )}
      </div>

      <nav className="flex items-center space-x-4">
        {/* User Profile Dropdown */}
        {currentUser ? (
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center space-x-2 text-white hover:text-teal-300 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-teal-500 rounded-full pr-2"
              aria-expanded={dropdownOpen}
              aria-haspopup="true"
            >
              <img
                src={displayAvatar}
                alt="User Avatar"
                className="w-10 h-10 rounded-full border-2 border-teal-500 shadow-md"
              />
              <span className="font-medium hidden sm:block">{displayName}</span>
              <svg
                className={`w-4 h-4 ml-1 transform transition-transform duration-200 ${
                  dropdownOpen ? 'rotate-180' : 'rotate-0'
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 9l-7 7-7-7"
                ></path>
              </svg>
            </button>

            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-dark-gray rounded-lg shadow-lg py-2 z-40 border border-white/10 animate-fade-in origin-top-right">
                <Link
                  to="/profile-settings"
                  className="block px-4 py-2 text-sm text-white/80 hover:bg-mid-gray hover:text-white transition-colors duration-200"
                  onClick={() => setDropdownOpen(false)}
                >
                  Profile Settings
                </Link>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-900/30 hover:text-red-300 transition-colors duration-200"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        ) : (
          <Link
            to="/login"
            className="btn-primary py-2 px-4 rounded-md text-sm bg-teal-600 hover:bg-teal-700 transition-colors duration-300"
          >
            Login
          </Link>
        )}
      </nav>
    </header>
  );
};

export default Header;
