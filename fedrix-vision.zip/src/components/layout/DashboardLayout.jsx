// src/components/layout/DashboardLayout.jsx
import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../common/Sidebar';
import Header from '../common/Header';
import Footer from '../common/Footer'; // Assuming you have a Footer component
import { useSidebar } from '../../context/SidebarContext';
import ProtectedRoute from '../routes/ProtectedRoute'; // Import ProtectedRoute

const DashboardLayout = () => {
  const { isSidebarOpen } = useSidebar();

  // Calculate dynamic padding for the main content area
  // pt-16 for header height (h-16)
  // lg:pl-[80px] for collapsed sidebar (w-20)
  // lg:pl-64 for expanded sidebar (w-64)
  const contentPaddingClass = `pt-16 pb-12 transition-all duration-300 ease-in-out
                               ${isSidebarOpen ? 'lg:pl-64' : 'lg:pl-[80px]'}`;

  return (
    <ProtectedRoute>
      <div className="flex min-h-screen bg-black-ops text-off-white">
        <Sidebar />
        <Header />

        {/* Main Content Area */}
        <main
          className={`flex-grow overflow-y-auto custom-scrollbar ${contentPaddingClass}`}
          style={{
            // Ensure content scrolls between header and footer
            minHeight: 'calc(100vh - 4rem)', // 4rem (h-16) for header, add footer height if fixed
            paddingTop: '4rem', // Match header height
            paddingBottom: '3rem', // Match footer height if fixed at 3rem (pb-12)
          }}
        >
          <Outlet /> {/* Renders child routes */}
        </main>

        <Footer /> {/* Assuming a Footer component exists */}
      </div>
    </ProtectedRoute>
  );
};

export default DashboardLayout;
