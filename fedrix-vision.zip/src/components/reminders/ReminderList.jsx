// src/components/reminders/ReminderList.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
// FaSave was missing from imports
import {
  FaPlus,
  FaBell,
  FaCheckCircle,
  FaTimesCircle,
  FaTrash,
  FaSpinner,
  FaEdit,
  FaSave,
} from 'react-icons/fa';
import { supabase } from '../../supabaseClient';
import { useAuth } from '../../context/AuthContext';
// eslint-disable-next-line no-unused-vars
import { useProfile } from '../../context/UserProfileContext';

const ReminderList = () => {
  const { currentUser } = useAuth();
  // eslint-disable-next-line no-unused-vars
  const { profile } = useProfile();
  const [reminders, setReminders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [currentReminder, setCurrentReminder] = useState(null);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const fetchReminders = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('reminders')
        .select('*')
        .eq('user_id', currentUser?.id)
        .order('due_date', { ascending: true });

      if (error) throw error;
      setReminders(data || []);
    } catch (error) {
      console.error('Error fetching reminders:', error.message);
      showMessage('Failed to load reminders.', 'error');
    } finally {
      setLoading(false);
    }
  }, [currentUser?.id]);

  useEffect(() => {
    if (currentUser?.id) {
      fetchReminders();

      const reminderChannel = supabase
        .channel('public:reminders')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'reminders' },
          (payload) => {
            console.log('Reminder change received!', payload);
            fetchReminders();
          },
        )
        .subscribe();

      return () => {
        supabase.removeChannel(reminderChannel);
      };
    }
  }, [currentUser?.id, fetchReminders]);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleAddReminder = () => {
    setCurrentReminder(null);
    setShowModal(true);
  };

  const handleEditReminder = (reminder) => {
    setCurrentReminder(reminder);
    setShowModal(true);
  };

  const handleDeleteReminder = async (id) => {
    // IMPORTANT: In a real application, use a custom modal for confirmation.
    if (window.confirm('Are you sure you want to delete this reminder?')) {
      setIsSaving(true);
      setMessage('');
      setMessageType('');
      try {
        const { error } = await supabase
          .from('reminders')
          .delete()
          .eq('id', id);
        if (error) throw error;
        showMessage('Reminder deleted successfully!', 'success');
        fetchReminders();
      } catch (error) {
        console.error('Error deleting reminder:', error.message);
        showMessage(`Error deleting reminder: ${error.message}`, 'error');
      } finally {
        setIsSaving(false);
      }
    }
  };

  const handleSaveReminder = async (reminderData) => {
    setIsSaving(true);
    setMessage('');
    setMessageType('');

    try {
      if (reminderData.id) {
        const { error } = await supabase
          .from('reminders')
          .update({
            title: reminderData.title,
            description: reminderData.description,
            due_date: reminderData.due_date,
            is_completed: reminderData.is_completed,
          })
          .eq('id', reminderData.id);
        if (error) throw error;
        showMessage('Reminder updated successfully!', 'success');
      } else {
        // eslint-disable-next-line no-unused-vars
        const { data, error } = await supabase
          .from('reminders')
          .insert({
            title: reminderData.title,
            description: reminderData.description,
            due_date: reminderData.due_date,
            is_completed: false,
            user_id: currentUser.id,
          })
          .select();
        if (error) throw error;
        showMessage('Reminder added successfully!', 'success');
      }
      setShowModal(false);
      fetchReminders();
    } catch (error) {
      console.error('Error saving reminder:', error.message);
      showMessage(`Error saving reminder: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleComplete = async (reminder) => {
    setIsSaving(true);
    setMessage('');
    setMessageType('');
    try {
      const { error } = await supabase
        .from('reminders')
        .update({ is_completed: !reminder.is_completed })
        .eq('id', reminder.id);
      if (error) throw error;
      showMessage(
        `Reminder marked as ${!reminder.is_completed ? 'completed' : 'incomplete'}!`,
        'success',
      );
      fetchReminders();
    } catch (error) {
      console.error('Error updating reminder completion:', error.message);
      showMessage(`Failed to update reminder: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      className="dashboard p-6 animate-fade-in flex flex-col h-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-6 text-off-white">Reminders</h1>

      {message && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={`p-3 mb-4 rounded-md text-sm ${
            messageType === 'success'
              ? 'bg-green-700/30 text-green-300 border border-green-500'
              : 'bg-red-700/30 text-red-300 border border-red-500'
          }`}
        >
          {message}
        </motion.div>
      )}

      <motion.button
        onClick={handleAddReminder}
        className="btn-action mb-6 self-start flex items-center"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <FaPlus className="mr-2" /> Add New Reminder
      </motion.button>

      {loading ? (
        <div className="flex-grow flex items-center justify-center">
          <FaSpinner className="animate-spin text-teal-400 text-3xl mr-3" />
          <p className="text-light-gray text-lg">Loading reminders...</p>
        </div>
      ) : (
        <div className="hologram-tile p-6 rounded-xl shadow-lg border border-mid-gray flex-grow overflow-y-auto custom-scrollbar">
          {reminders.length === 0 ? (
            <div className="flex-grow flex items-center justify-center h-full">
              <p className="text-light-gray text-lg text-center">
                No reminders found. Add one to get started!
              </p>
            </div>
          ) : (
            <ul className="space-y-4">
              <AnimatePresence>
                {reminders.map((reminder) => (
                  <motion.li
                    key={reminder.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    transition={{ duration: 0.3 }}
                    className={`hologram-tile p-4 flex items-center justify-between
                                ${reminder.is_completed ? 'opacity-60 line-through' : ''}`}
                  >
                    <div className="flex items-center flex-grow min-w-0">
                      <FaBell
                        className={`text-xl mr-3 ${reminder.is_completed ? 'text-mid-gray' : 'text-teal-400'}`}
                      />
                      <div className="flex-grow min-w-0">
                        <h3 className="text-lg font-semibold text-off-white truncate">
                          {reminder.title}
                        </h3>
                        {reminder.description && (
                          <p className="text-sm text-light-gray truncate">
                            {reminder.description}
                          </p>
                        )}
                        <p className="text-xs text-mid-gray mt-1">
                          Due: {new Date(reminder.due_date).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2 ml-4 flex-shrink-0">
                      <motion.button
                        onClick={() => handleToggleComplete(reminder)}
                        className={`btn-primary p-2 rounded-full ${reminder.is_completed ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-green-600 hover:bg-green-700'} text-off-white`}
                        title={
                          reminder.is_completed
                            ? 'Mark Incomplete'
                            : 'Mark Complete'
                        }
                        disabled={isSaving}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        {reminder.is_completed ? (
                          <FaTimesCircle />
                        ) : (
                          <FaCheckCircle />
                        )}
                      </motion.button>
                      <motion.button
                        onClick={() => handleEditReminder(reminder)}
                        className="btn-primary p-2 rounded-full bg-teal-600 hover:bg-teal-700 text-off-white"
                        title="Edit Reminder"
                        disabled={isSaving}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <FaEdit />
                      </motion.button>
                      <motion.button
                        onClick={() => handleDeleteReminder(reminder.id)}
                        className="btn-primary p-2 rounded-full bg-red-600 hover:bg-red-700 text-off-white"
                        title="Delete Reminder"
                        disabled={isSaving}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <FaTrash />
                      </motion.button>
                    </div>
                  </motion.li>
                ))}
              </AnimatePresence>
            </ul>
          )}
        </div>
      )}

      <AnimatePresence>
        {showModal && (
          <motion.div
            className="fixed inset-0 bg-black-ops bg-opacity-70 flex items-center justify-center z-50 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="glass-effect p-8 rounded-xl shadow-2xl w-full max-w-md border border-mid-gray relative"
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
            >
              <h2 className="text-2xl font-bold text-off-white mb-6">
                {currentReminder ? 'Edit Reminder' : 'Add New Reminder'}
              </h2>

              <div className="space-y-4">
                <div>
                  <label
                    htmlFor="reminderTitle"
                    className="block text-light-gray text-sm font-bold mb-2"
                  >
                    Title:
                  </label>
                  <input
                    type="text"
                    id="reminderTitle"
                    className="email-input"
                    value={currentReminder?.title || ''}
                    onChange={(e) =>
                      setCurrentReminder((prev) => ({
                        ...prev,
                        title: e.target.value,
                      }))
                    }
                    disabled={isSaving}
                  />
                </div>
                <div>
                  <label
                    htmlFor="reminderDescription"
                    className="block text-light-gray text-sm font-bold mb-2"
                  >
                    Description (Optional):
                  </label>
                  <textarea
                    id="reminderDescription"
                    className="email-input min-h-[80px]"
                    value={currentReminder?.description || ''}
                    onChange={(e) =>
                      setCurrentReminder((prev) => ({
                        ...prev,
                        description: e.target.value,
                      }))
                    }
                    disabled={isSaving}
                  ></textarea>
                </div>
                <div>
                  <label
                    htmlFor="reminderDueDate"
                    className="block text-light-gray text-sm font-bold mb-2"
                  >
                    Due Date:
                  </label>
                  <input
                    type="datetime-local"
                    id="reminderDueDate"
                    className="email-input"
                    value={
                      currentReminder?.due_date
                        ? new Date(currentReminder.due_date)
                            .toISOString()
                            .substring(0, 16)
                        : new Date().toISOString().substring(0, 16)
                    }
                    onChange={(e) =>
                      setCurrentReminder((prev) => ({
                        ...prev,
                        due_date: e.target.value,
                      }))
                    }
                    disabled={isSaving}
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <motion.button
                  onClick={() => setShowModal(false)}
                  className="btn-primary bg-mid-gray hover:bg-dark-gray text-light-gray"
                  disabled={isSaving}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <FaTimesCircle className="mr-2" /> Cancel
                </motion.button>
                <motion.button
                  onClick={() => handleSaveReminder(currentReminder)}
                  className="btn-action"
                  disabled={isSaving || !currentReminder?.title}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {isSaving ? (
                    <FaSpinner className="animate-spin mr-2" />
                  ) : (
                    <FaSave className="mr-2" />
                  )}{' '}
                  Save Reminder
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default ReminderList;
