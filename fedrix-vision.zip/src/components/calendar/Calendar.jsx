// src/components/calendar/Calendar.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { Calendar as BigCalendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { motion, AnimatePresence } from 'framer-motion';
// eslint-disable-next-line no-unused-vars
import {
  FaTrash,
  FaSpinner,
  FaTimesCircle,
  FaSave,
  FaPlusCircle,
} from 'react-icons/fa'; // Ensure all icons are imported
import { supabase } from '../../supabaseClient';
import { useAuth } from '../../context/AuthContext';
// eslint-disable-next-line no-unused-vars
import { useProfile } from '../../context/UserProfileContext';

const localizer = momentLocalizer(moment);

const Calendar = () => {
  const { currentUser } = useAuth();
  // eslint-disable-next-line no-unused-vars
  const { profile } = useProfile();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [newEvent, setNewEvent] = useState({
    title: '',
    start: new Date(),
    end: new Date(),
    allDay: false,
    description: '',
    color: '#06B6D4',
  });
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const eventColors = ['#06B6D4', '#14B8A6', '#8B5CF6', '#EAB308', '#EF4444'];

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('user_id', currentUser?.id);

      if (error) throw error;
      setEvents(
        data.map((event) => ({
          ...event,
          start: new Date(event.start),
          end: new Date(event.end),
        })),
      );
    } catch (error) {
      console.error('Error fetching events:', error.message);
      showMessage('Failed to load events.', 'error');
    } finally {
      setLoading(false);
    }
  }, [currentUser?.id]);

  useEffect(() => {
    if (currentUser?.id) {
      fetchEvents();

      const eventChannel = supabase
        .channel('public:events')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'events' },
          (payload) => {
            console.log('Event change received!', payload);
            fetchEvents();
          },
        )
        .subscribe();

      return () => {
        supabase.removeChannel(eventChannel);
      };
    }
  }, [currentUser?.id, fetchEvents]);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleSelectSlot = ({ start, end, action }) => {
    if (action === 'click' || action === 'doubleClick') {
      setSelectedEvent(null);
      setNewEvent({
        title: '',
        start: start,
        end: end,
        allDay:
          moment(start).isSame(moment(end), 'day') && action === 'doubleClick',
        description: '',
        color: '#06B6D4',
      });
      setShowModal(true);
    }
  };

  const handleSelectEvent = (event) => {
    setSelectedEvent(event);
    setNewEvent({
      title: event.title,
      start: event.start,
      end: event.end,
      allDay: event.allDay,
      description: event.description || '',
      color: event.color || '#06B6D4',
    });
    setShowModal(true);
  };

  const handleSaveEvent = async () => {
    setIsSaving(true);
    setMessage('');
    setMessageType('');

    try {
      const eventToSave = {
        title: newEvent.title,
        start: newEvent.start.toISOString(),
        end: newEvent.end.toISOString(),
        allDay: newEvent.allDay,
        description: newEvent.description,
        color: newEvent.color,
        user_id: currentUser.id,
      };

      if (selectedEvent) {
        const { error } = await supabase
          .from('events')
          .update(eventToSave)
          .eq('id', selectedEvent.id);
        if (error) throw error;
        showMessage('Event updated successfully!', 'success');
      } else {
        // FIX: Removed 'data: insertedEvent' as it was unused.
        const { error } = await supabase
          .from('events')
          .insert(eventToSave)
          .select();
        if (error) throw error;
        showMessage('Event added successfully!', 'success');
      }
      setShowModal(false);
      fetchEvents();
    } catch (error) {
      console.error('Error saving event:', error.message);
      showMessage(`Error saving event: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteEvent = async () => {
    if (!selectedEvent) return;
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    setIsSaving(true);
    setMessage('');
    setMessageType('');
    setShowDeleteConfirm(false);

    try {
      const { error } = await supabase
        .from('events')
        .delete()
        .eq('id', selectedEvent.id);
      if (error) throw error;
      showMessage('Event deleted successfully!', 'success');
      setShowModal(false);
      setSelectedEvent(null);
      fetchEvents();
    } catch (error) {
      console.error('Error deleting event:', error.message);
      showMessage(`Error deleting event: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const eventPropGetter = useCallback(
    (event) => ({
      style: {
        backgroundColor: event.color || '#06B6D4',
        borderRadius: '5px',
        opacity: 0.9,
        color: 'white',
        border: `1px solid ${event.color || '#06B6D4'}`,
      },
    }),
    [],
  );

  return (
    <motion.div
      className="dashboard p-6 animate-fade-in flex flex-col h-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-6 text-off-white">Calendar</h1>

      {message && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={`p-3 mb-4 rounded-md text-sm ${
            messageType === 'success'
              ? 'bg-green-700/30 text-green-300 border border-green-500'
              : 'bg-red-700/30 text-red-300 border border-red-500'
          }`}
        >
          {message}
        </motion.div>
      )}

      <div className="flex justify-end mb-4">
        <motion.button
          onClick={() => {
            setSelectedEvent(null);
            setNewEvent({
              title: '',
              start: new Date(),
              end: new Date(),
              allDay: false,
              description: '',
              color: '#06B6D4',
            });
            setShowModal(true);
          }}
          className="btn-action flex items-center px-4 py-2"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <FaPlusCircle className="mr-2" /> Add New Event
        </motion.button>
      </div>

      <div className="hologram-tile flex-grow p-4 rounded-xl shadow-lg border border-mid-gray">
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <FaSpinner className="animate-spin text-teal-400 text-3xl" />
            <p className="ml-3 text-light-gray">Loading calendar...</p>
          </div>
        ) : (
          <BigCalendar
            localizer={localizer}
            events={events}
            startAccessor="start"
            endAccessor="end"
            selectable
            onSelectSlot={handleSelectSlot}
            onSelectEvent={handleSelectEvent}
            style={{ height: 'calc(100vh - 250px)' }}
            className="react-big-calendar-custom-theme"
            eventPropGetter={eventPropGetter}
          />
        )}
      </div>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black-ops bg-opacity-70 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              className="glass-effect p-8 rounded-xl shadow-2xl w-full max-w-md border border-mid-gray relative"
            >
              <h2 className="text-2xl font-bold text-off-white mb-6">
                {selectedEvent ? 'Edit Event' : 'Add New Event'}
              </h2>

              <div className="mb-4">
                <label
                  htmlFor="eventTitle"
                  className="block text-light-gray text-sm font-bold mb-2"
                >
                  Title:
                </label>
                <input
                  type="text"
                  id="eventTitle"
                  className="email-input"
                  value={newEvent.title}
                  onChange={(e) =>
                    setNewEvent({ ...newEvent, title: e.target.value })
                  }
                  disabled={isSaving}
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="eventDescription"
                  className="block text-light-gray text-sm font-bold mb-2"
                >
                  Description:
                </label>
                <textarea
                  id="eventDescription"
                  className="email-input min-h-[80px]"
                  value={newEvent.description}
                  onChange={(e) =>
                    setNewEvent({ ...newEvent, description: e.target.value })
                  }
                  disabled={isSaving}
                ></textarea>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label
                    htmlFor="eventStart"
                    className="block text-light-gray text-sm font-bold mb-2"
                  >
                    Start:
                  </label>
                  <input
                    type="datetime-local"
                    id="eventStart"
                    className="email-input"
                    value={moment(newEvent.start).format('YYYY-MM-DDTHH:mm')}
                    onChange={(e) =>
                      setNewEvent({
                        ...newEvent,
                        start: new Date(e.target.value),
                      })
                    }
                    disabled={isSaving}
                  />
                </div>
                <div>
                  <label
                    htmlFor="eventEnd"
                    className="block text-light-gray text-sm font-bold mb-2"
                  >
                    End:
                  </label>
                  <input
                    type="datetime-local"
                    id="eventEnd"
                    className="email-input"
                    value={moment(newEvent.end).format('YYYY-MM-DDTHH:mm')}
                    onChange={(e) =>
                      setNewEvent({
                        ...newEvent,
                        end: new Date(e.target.value),
                      })
                    }
                    disabled={isSaving}
                  />
                </div>
              </div>
              <div className="mb-4 flex items-center">
                <input
                  type="checkbox"
                  id="allDay"
                  className="form-checkbox h-5 w-5 text-teal-600 rounded border-gray-300 focus:ring-teal-500 bg-mid-gray"
                  checked={newEvent.allDay}
                  onChange={(e) =>
                    setNewEvent({ ...newEvent, allDay: e.target.checked })
                  }
                  disabled={isSaving}
                />
                <label
                  htmlFor="allDay"
                  className="ml-2 text-light-gray text-sm"
                >
                  All Day Event
                </label>
              </div>
              <div className="mb-6">
                <label className="block text-light-gray text-sm font-bold mb-2">
                  Color:
                </label>
                <div className="flex space-x-2">
                  {eventColors.map((color) => (
                    <motion.div
                      key={color}
                      className={`w-8 h-8 rounded-full cursor-pointer border-2 ${newEvent.color === color ? 'border-teal-400' : 'border-mid-gray'}`}
                      style={{ backgroundColor: color }}
                      onClick={() => setNewEvent({ ...newEvent, color: color })}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    ></motion.div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                {selectedEvent && (
                  <motion.button
                    onClick={handleDeleteEvent}
                    className="btn-primary bg-red-600 hover:bg-red-700 text-off-white"
                    disabled={isSaving}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <FaTrash className="mr-2" /> Delete
                  </motion.button>
                )}
                <motion.button
                  onClick={() => setShowModal(false)}
                  className="btn-primary bg-mid-gray hover:bg-dark-gray text-light-gray"
                  disabled={isSaving}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <FaTimesCircle className="mr-2" /> Cancel
                </motion.button>
                <motion.button
                  onClick={handleSaveEvent}
                  className="btn-action"
                  disabled={isSaving || !newEvent.title}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {isSaving ? (
                    <FaSpinner className="animate-spin mr-2" />
                  ) : (
                    <FaSave className="mr-2" />
                  )}{' '}
                  {selectedEvent ? 'Update' : 'Add'}
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {showDeleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black-ops bg-opacity-70 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              className="glass-effect p-8 rounded-xl shadow-2xl w-full max-w-sm border border-mid-gray relative text-center"
            >
              <h3 className="text-xl font-bold text-white mb-4">
                Confirm Deletion
              </h3>
              <p className="text-white/80 mb-6">
                Are you sure you want to delete the event &quot;
                {selectedEvent?.title}&quot;?
              </p>
              <div className="flex justify-center space-x-4">
                <motion.button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="btn-primary bg-mid-gray hover:bg-dark-gray text-light-gray px-6 py-2"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Cancel
                </motion.button>
                <motion.button
                  onClick={confirmDelete}
                  className="btn-primary bg-red-600 hover:bg-red-700 text-off-white px-6 py-2"
                  disabled={isSaving}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {isSaving ? (
                    <FaSpinner className="animate-spin mr-2" />
                  ) : (
                    <FaTrash className="mr-2" />
                  )}{' '}
                  Delete
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default Calendar;
