// src/components/calendar/SocialMediaCalendar.js
// Manages scheduled social media posts. Users can add new post ideas,
// generate content using the AI agent, and approve posts.
// Features real-time updates from Supabase.
import React, { useState, useEffect, useCallback, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion'; // For UI animations
import { supabase } from '../../supabaseClient'; // Supabase client instance
import { useAuth } from '../../context/AuthContext'; // Auth context for user data
import { useProfile } from '../../context/UserProfileContext'; // User profile context for user ID and role
import { AgentAIContext } from '../../context/AgentAIContext'; // AI agent context for content generation
import dayjs from 'dayjs'; // For date formatting

const SocialMediaCalendar = () => {
  const { user } = useAuth(); // Get current authenticated user
  const { profile, profileLoading } = useProfile(); // Get profile and its loading state
  const { generateContent, loading: aiLoading } = useContext(AgentAIContext); // AI generation function and loading state

  const [posts, setPosts] = useState([]); // State to store scheduled posts
  const [platformFilter, setPlatformFilter] = useState(''); // State for filtering by platform
  const [projectFilter, setProjectFilter] = useState(''); // State for filtering by project
  const [newDate, setNewDate] = useState(''); // State for new post date input
  const [idea, setIdea] = useState(''); // State for content idea input
  const [platformInput, setPlatformInput] = useState(''); // State for new post platform input
  const [projectInput, setProjectInput] = useState(''); // State for new post project input
  const [errorMsg, setErrorMsg] = useState(null); // State for displaying errors
  const [loading, setLoading] = useState(true); // Overall loading state for fetching/saving

  // Callback to fetch scheduled posts from Supabase
  const fetchPosts = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null); // Clear previous errors
    try {
      // Select scheduled posts and join with profiles to get the creator's name
      const { data, error } = await supabase
        .from('scheduled_posts')
        .select('*, profiles(name)') // Select all from scheduled_posts, and name from profiles
        .order('date', { ascending: true }); // Order by scheduled date

      if (error) throw error;

      // Map data to include the creator's name directly in each post object
      const mappedData = data.map((post) => ({
        ...post,
        created_by_name: post.profiles ? post.profiles.name : 'Unknown User',
      }));

      // Filter posts based on user's role: admin/superadmin see all, others see only their own.
      const visible =
        profile?.tier === 'admin' || profile?.tier === 'superadmin'
          ? mappedData
          : mappedData.filter((p) => p.created_by === profile?.id);

      setPosts(visible || []);
    } catch (err) {
      console.error('Failed to fetch scheduled posts:', err);
      setErrorMsg(err.message || 'Failed to load scheduled posts.');
      setPosts([]); // Clear posts on error
    } finally {
      setLoading(false); // End loading
    }
  }, [profile?.id, profile?.tier]); // Re-run if profile ID or tier changes

  // Effect hook for initial data fetch and real-time subscription
  useEffect(() => {
    // Only fetch and subscribe if user is authenticated and profile is loaded
    if (!profileLoading && user?.id && profile?.id) {
      fetchPosts(); // Initial fetch

      // Set up real-time listener for 'scheduled_posts' table
      const channel = supabase
        .channel('social-posts-sync')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'scheduled_posts' },
          fetchPosts, // Trigger re-fetch on any change
        )
        .subscribe();

      // Cleanup the real-time subscription when the component unmounts
      return () => supabase.removeChannel(channel);
    } else if (!profileLoading && (!user?.id || !profile?.id)) {
      // If not authenticated or profile not ready, clear posts and stop loading
      setPosts([]);
      setLoading(false);
      setErrorMsg(
        'Please ensure you are logged in and your profile is set up to manage social media posts.',
      );
    }
  }, [user?.id, profile?.id, profileLoading, fetchPosts]); // Dependencies for effect

  // Filtered posts based on selected platform and project
  const filteredPosts = posts.filter(
    (p) =>
      (!platformFilter || p.platform === platformFilter) &&
      (!projectFilter || p.project === projectFilter),
  );

  // Extract unique platforms and projects for filter dropdowns
  const uniquePlatforms = [
    ...new Set(posts.map((p) => p.platform).filter(Boolean)),
  ]; // Filter out empty strings
  const uniqueProjects = [
    ...new Set(posts.map((p) => p.project).filter(Boolean)),
  ]; // Filter out empty strings

  // Handle adding a new scheduled post
  const handleAdd = async (e) => {
    e.preventDefault();
    setErrorMsg(null); // Clear previous errors

    if (!user?.id || !profile?.id) {
      setErrorMsg(
        'User not authenticated or profile not loaded. Cannot add post.',
      );
      return;
    }
    if (!newDate || !idea.trim()) {
      setErrorMsg('Please provide a date and a content idea.');
      return;
    }

    setLoading(true); // Indicate saving
    try {
      // Generate content using the AI agent
      const generatedContent = await generateContent(idea);

      if (!generatedContent) {
        throw new Error(
          'AI content generation failed or returned empty content.',
        );
      }

      // Insert the new scheduled post into Supabase
      const { error } = await supabase.from('scheduled_posts').insert({
        content: generatedContent,
        date: newDate,
        platform: platformInput.trim() || 'General', // Use input, default to "General"
        project: projectInput.trim() || 'General', // Use input, default to "General"
        approved: false, // New posts are not approved by default
        created_by: profile.id, // Link to creator
      });
      if (error) throw error;

      // Clear input fields on success
      setIdea('');
      setNewDate('');
      setPlatformInput('');
      setProjectInput('');
      // fetchPosts() will be triggered by real-time listener.
    } catch (err) {
      console.error('Error creating social media post:', err);
      setErrorMsg(err.message || 'Failed to create social media post.');
    } finally {
      setLoading(false); // End saving indication
    }
  };

  // Handle approving/unapproving a social media post
  const handleApprove = async (post) => {
    setErrorMsg(null); // Clear previous errors
    setLoading(true); // Indicate saving
    try {
      const { error } = await supabase
        .from('scheduled_posts')
        .update({ approved: !post.approved }) // Toggle approved status
        .eq('id', post.id); // Match by ID

      if (error) throw error;
      // fetchPosts() will be triggered by real-time listener.
    } catch (err) {
      console.error('Error approving post:', err);
      setErrorMsg(err.message || 'Failed to update post approval status.');
    } finally {
      setLoading(false); // End saving indication
    }
  };

  const handleDelete = async (postId, postContent) => {
    if (
      !window.confirm(
        `Are you sure you want to delete this post: "${postContent.substring(0, 50)}..."?`,
      )
    ) {
      return;
    }
    setErrorMsg(null);
    setLoading(true);
    try {
      const { error } = await supabase
        .from('scheduled_posts')
        .delete()
        .eq('id', postId);
      if (error) throw error;
      // fetchPosts() will be triggered by real-time listener.
    } catch (err) {
      console.error('Error deleting post:', err);
      setErrorMsg(err.message || 'Failed to delete post.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="mt-10 bg-white/5 p-6 border border-white/10 rounded-xl shadow-lg backdrop-blur-md space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
    >
      <h3 className="text-xl text-white font-bold mb-4 flex items-center gap-3 border-b border-white/20 pb-3">
        📲 Social Media Schedule
      </h3>

      {errorMsg && (
        <div className="text-red-400 bg-red-900/20 border border-red-400/50 p-3 rounded-md mb-4 text-center">
          {errorMsg}
        </div>
      )}

      {/* Filters for platforms and projects */}
      <div className="flex flex-col sm:flex-row items-center gap-4 mb-4">
        <label
          htmlFor="platformFilter"
          className="text-white/70 text-sm font-medium"
        >
          Filter:
        </label>
        <select
          id="platformFilter"
          value={platformFilter}
          onChange={(e) => setPlatformFilter(e.target.value)}
          className="bg-black/40 border border-white/10 text-white text-sm px-3 py-2 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
        >
          <option value="">All Platforms</option>
          {uniquePlatforms.map((p, i) => (
            <option key={i} value={p}>
              {p}
            </option>
          ))}
        </select>

        <select
          value={projectFilter}
          onChange={(e) => setProjectFilter(e.target.value)}
          className="bg-black/40 border border-white/10 text-white text-sm px-3 py-2 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
        >
          <option value="">All Projects</option>
          {uniqueProjects.map((p, i) => (
            <option key={i} value={p}>
              {p}
            </option>
          ))}
        </select>
      </div>

      {/* Form to add a new social media post */}
      <motion.div
        className="bg-black/40 border border-white/10 rounded-xl p-5 shadow-inner"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <h4 className="text-lg font-semibold text-white mb-3">
          Add New Post Idea
        </h4>
        <form onSubmit={handleAdd} className="space-y-3">
          <div>
            <label
              htmlFor="ideaInput"
              className="block text-white/70 text-sm font-medium mb-1"
            >
              Content Idea (for AI generation)
            </label>
            <textarea
              id="ideaInput"
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              placeholder="e.g., 'Write a tweet about new car wash service with emoji'"
              className="w-full p-2 rounded-lg bg-black/40 border border-white/10 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              rows="3"
              required
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label
                htmlFor="postDate"
                className="block text-white/70 text-sm font-medium mb-1"
              >
                Schedule Date
              </label>
              <input
                type="date"
                id="postDate"
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="w-full p-2 rounded-lg bg-black/40 border border-white/10 text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                required
              />
            </div>
            <div>
              <label
                htmlFor="platformInput"
                className="block text-white/70 text-sm font-medium mb-1"
              >
                Platform
              </label>
              <input
                type="text"
                id="platformInput"
                value={platformInput}
                onChange={(e) => setPlatformInput(e.target.value)}
                placeholder="e.g., Facebook, Twitter"
                className="w-full p-2 rounded-lg bg-black/40 border border-white/10 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>
            <div>
              <label
                htmlFor="projectInput"
                className="block text-white/70 text-sm font-medium mb-1"
              >
                Project
              </label>
              <input
                type="text"
                id="projectInput"
                value={projectInput}
                onChange={(e) => setProjectInput(e.target.value)}
                placeholder="e.g., Summer Campaign"
                className="w-full p-2 rounded-lg bg-black/40 border border-white/10 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>
          </div>
          <motion.button
            type="submit"
            disabled={aiLoading || loading || !user?.id} // Disable if AI is generating or overall loading
            className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-base"
            whileTap={{ scale: 0.98 }}
            whileHover={{ scale: 1.02 }}
          >
            {aiLoading
              ? 'Generating Content...'
              : loading
                ? 'Adding Post...'
                : 'Add Post Idea'}
          </motion.button>
        </form>
      </motion.div>

      {/* List of scheduled posts */}
      <h3 className="text-xl font-semibold text-white mb-4 mt-8">
        Scheduled Posts ({filteredPosts.length})
      </h3>
      {loading && filteredPosts.length === 0 ? (
        <p className="text-white/70 text-center py-4">
          Loading scheduled posts...
        </p>
      ) : filteredPosts.length === 0 ? (
        <p className="text-white/70 text-center py-4">
          No social media posts found for the current filters. Add one above!
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          <AnimatePresence>
            {filteredPosts.map((post) => (
              <motion.div
                key={post.id}
                className="bg-black/40 border border-white/10 p-5 rounded-lg text-white shadow-inner flex flex-col sm:flex-row justify-between items-start sm:items-center"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
                layout // For smooth animation when items are added/removed
              >
                <div className="flex-grow mb-3 sm:mb-0">
                  <p className="text-white text-base font-medium whitespace-pre-wrap">
                    {post.content}
                  </p>
                  <div className="text-white/60 text-xs mt-2 flex flex-wrap gap-2">
                    <span className="bg-gray-700/20 px-2 py-1 rounded-full">
                      {post.platform}
                    </span>
                    <span className="bg-gray-700/20 px-2 py-1 rounded-full">
                      {post.project}
                    </span>
                    <span className="bg-gray-700/20 px-2 py-1 rounded-full">
                      Created by: {post.created_by_name}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-start sm:items-end gap-2 sm:gap-0 sm:ml-4 flex-shrink-0">
                  <span className="text-xs text-white/60 bg-gray-700/10 border border-gray-700 px-3 py-1 rounded-full mb-2">
                    {dayjs(post.date).format('MMM D, YYYY')}
                  </span>
                  {/* Approval button, only visible to admins/superadmins */}
                  {(profile?.tier === 'admin' ||
                    profile?.tier === 'superadmin') && (
                    <motion.button
                      onClick={() => handleApprove(post)}
                      className={`px-4 py-1 rounded-md text-sm font-semibold transition-colors shadow-md ${post.approved ? 'bg-green-700/30 text-green-400 hover:bg-green-700/50' : 'bg-yellow-700/30 text-yellow-400 hover:bg-yellow-700/50'}`}
                      whileTap={{ scale: 0.98 }}
                    >
                      {post.approved ? 'Approved' : 'Approve'}
                    </motion.button>
                  )}
                  {(profile?.tier === 'admin' ||
                    profile?.tier === 'superadmin') && (
                    <button
                      onClick={() => handleDelete(post.id, post.content)}
                      className="px-4 py-1 rounded-md text-xs bg-red-700/30 text-red-400 hover:bg-red-700/50 transition-colors mt-1"
                    >
                      Delete
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </motion.div>
  );
};

export default SocialMediaCalendar;
