// src/components/calendar/EventModal.jsx
// A modal component for adding or editing calendar events.
// It allows users to input event details, dates, and assign properties like project, priority, and tags.
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types'; // For prop type validation
import { createPortal } from 'react-dom'; // For rendering modal outside root DOM
import { motion, AnimatePresence } from 'framer-motion'; // For UI animations
import { formatDateTimeLocal } from '../../utils/dateUtils'; // Utility for date formatting

const EventModal = ({ slot, event, onClose, onSave }) => {
  // State variables for all event fields
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [project, setProject] = useState('');
  const [priority, setPriority] = useState('Medium'); // Default priority
  const [tag, setTag] = useState('');
  const [tagColor, setTagColor] = useState('#f15bb5'); // Default tag color (a vibrant pink)
  const [type, setType] = useState('meeting'); // Default event type
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [error, setError] = useState(null); // Error state for validation

  // Effect to populate form fields when an event is selected for editing, or a slot for creation
  useEffect(() => {
    setError(null); // Clear errors on modal open/event change
    if (event) {
      // If editing an existing event, populate with event data
      setTitle(event.title || '');
      setDesc(event.description || '');
      // Format Date objects to string for datetime-local input
      setStart(event.start ? formatDateTimeLocal(event.start) : '');
      setEnd(event.end ? formatDateTimeLocal(event.end) : '');
      setProject(event.project || '');
      setPriority(event.priority || 'Medium');
      setTag(event.tag || '');
      setTagColor(event.tag_color || '#f15bb5');
      setType(event.type || 'meeting');
    } else if (slot?.start) {
      // If creating a new event from a slot selection, pre-fill start/end times
      setStart(formatDateTimeLocal(slot.start));
      setEnd(formatDateTimeLocal(slot.end || slot.start)); // End time might be same as start for clicks
      // Reset other fields for a clean new event form
      setTitle('');
      setDesc('');
      setProject('');
      setPriority('Medium');
      setTag('');
      setTagColor('#f15bb5');
      setType('meeting');
    }
  }, [event, slot]);

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);

    // Basic validation
    if (!title.trim() || !start || !end) {
      setError('Title, Start Date, and End Date are required.');
      return;
    }
    if (new Date(start) >= new Date(end)) {
      setError('End date must be after start date.');
      return;
    }

    // Call the onSave prop with the collected event data
    onSave({
      // If event.id exists, it means we are updating, otherwise it's a new event
      ...(event?.id && { id: event.id }),
      title: title.trim(),
      description: desc.trim(),
      start: new Date(start), // Convert string back to Date object for Supabase/BigCalendar
      end: new Date(end),
      project: project.trim(),
      tag: tag.trim(),
      tag_color: tagColor,
      priority,
      type,
    });

    onClose(); // Close the modal after saving
  };

  // If modal is not open, render nothing
  if (!slot && !event) return null;

  return createPortal(
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 30, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 100, damping: 15 }}
          className="bg-black border border-white/10 p-6 rounded-2xl max-w-lg w-full text-white backdrop-blur-md shadow-2xl"
        >
          <h3 className="text-xl font-bold mb-4 border-b border-white/20 pb-3">
            {event ? '✏️ Edit Event' : '➕ Add New Event'}
          </h3>

          {error && (
            <div className="text-red-400 bg-red-900/20 border border-red-400/50 p-3 rounded-md mb-4 text-center">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="eventTitle"
                className="block text-white/70 text-sm font-medium mb-1"
              >
                Title
              </label>
              <input
                type="text"
                id="eventTitle"
                required
                placeholder="Event title"
                className="w-full p-3 rounded-lg bg-black/40 border border-white/10 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div>
              <label
                htmlFor="eventDesc"
                className="block text-white/70 text-sm font-medium mb-1"
              >
                Description
              </label>
              <textarea
                id="eventDesc"
                rows="3"
                placeholder="Detailed description of the event..."
                className="w-full p-3 rounded-lg bg-black/40 border border-white/10 text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
              ></textarea>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="eventStart"
                  className="block text-white/70 text-sm font-medium mb-1"
                >
                  Start Time
                </label>
                <input
                  type="datetime-local"
                  id="eventStart"
                  value={start}
                  onChange={(e) => setStart(e.target.value)}
                  className="w-full p-3 bg-black/40 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  required
                />
              </div>
              <div>
                <label
                  htmlFor="eventEnd"
                  className="block text-white/70 text-sm font-medium mb-1"
                >
                  End Time
                </label>
                <input
                  type="datetime-local"
                  id="eventEnd"
                  value={end}
                  onChange={(e) => setEnd(e.target.value)}
                  className="w-full p-3 bg-black/40 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="eventProject"
                  className="block text-white/70 text-sm font-medium mb-1"
                >
                  Project
                </label>
                <input
                  type="text"
                  id="eventProject"
                  placeholder="e.g., Q3 Marketing"
                  value={project}
                  onChange={(e) => setProject(e.target.value)}
                  className="w-full p-3 bg-black/40 border border-white/10 rounded-lg text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>
              <div>
                <label
                  htmlFor="eventType"
                  className="block text-white/70 text-sm font-medium mb-1"
                >
                  Type
                </label>
                <select
                  id="eventType"
                  aria-label="Event Type"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full p-3 bg-black/40 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                >
                  <option value="meeting">Meeting</option>
                  <option value="appointment">Appointment</option>
                  <option value="reminder">Reminder</option>
                  <option value="task">Task</option>
                  <option value="deadline">Deadline</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 items-end">
              <div>
                <label
                  htmlFor="eventPriority"
                  className="block text-white/70 text-sm font-medium mb-1"
                >
                  Priority
                </label>
                <select
                  id="eventPriority"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full p-3 bg-black/40 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
              </div>
              <div>
                <label
                  htmlFor="eventTag"
                  className="block text-white/70 text-sm font-medium mb-1"
                >
                  Custom Tag
                </label>
                <input
                  type="text"
                  id="eventTag"
                  placeholder="e.g., Client Call"
                  value={tag}
                  onChange={(e) => setTag(e.target.value)}
                  className="w-full p-3 bg-black/40 border border-white/10 rounded-lg text-white placeholder-white/60 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>
            </div>
            <div>
              <label
                htmlFor="eventTagColor"
                className="block text-white/70 text-sm font-medium mb-1"
              >
                Tag Color
              </label>
              <input
                type="color"
                id="eventTagColor"
                value={tagColor}
                onChange={(e) => setTagColor(e.target.value)}
                className="w-full h-12 p-0 bg-transparent border border-white/20 rounded-lg overflow-hidden cursor-pointer"
                title="Choose tag color"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-semibold transition-colors shadow-md"
              >
                Cancel
              </button>
              <motion.button
                type="submit"
                className="px-8 py-2 bg-gradient-to-r from-teal-500 to-green-500 hover:from-teal-600 hover:to-green-600 text-white rounded-lg font-bold shadow-lg transition-all duration-300 transform hover:scale-105"
                whileTap={{ scale: 0.98 }}
                whileHover={{ scale: 1.02 }}
              >
                {event ? 'Update Event' : 'Create Event'}
              </motion.button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>,
    document.body,
  );
};

EventModal.propTypes = {
  slot: PropTypes.shape({
    start: PropTypes.instanceOf(Date),
    // end is optional for slot as it might be a click on a single day
    end: PropTypes.instanceOf(Date),
    action: PropTypes.string, // 'click' or 'select'
  }),
  event: PropTypes.shape({
    id: PropTypes.number,
    title: PropTypes.string,
    description: PropTypes.string,
    start: PropTypes.instanceOf(Date),
    end: PropTypes.instanceOf(Date),
    project: PropTypes.string,
    priority: PropTypes.string,
    tag: PropTypes.string,
    tag_color: PropTypes.string,
    type: PropTypes.string,
  }),
  onClose: PropTypes.func.isRequired,
  onSave: PropTypes.func.isRequired,
};

export default EventModal;
