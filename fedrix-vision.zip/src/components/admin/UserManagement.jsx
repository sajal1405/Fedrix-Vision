// src/components/admin/UserManagement.jsx
// This component provides a mock interface for Super Admin functionalities:
// User Management, Role Assignment, and basic Permission Customization.
// All data is currently mocked. In a real application, this would integrate with a backend.

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FaEdit,
  FaTrash,
  FaPlus,
  FaCheckCircle,
  FaTimesCircle,
  FaUserCog,
  FaUnlockAlt,
  FaBan,
  FaSave,
  FaSpinner,
  FaUsers,
} from 'react-icons/fa';
import PropTypes from 'prop-types';
import AnimatedToggleSwitch from '../common/AnimatedToggleSwitch';
import { useAuth } from '../../context/AuthContext';
import { useProfile } from '../../context/UserProfileContext';

// --- Mock Data for Development ---
const mockUsers = [
  {
    id: 'user1',
    name: 'Sajal Fedrix',
    email: 'sajal@fedrixgroup.com',
    role: 'super_admin',
    status: 'active',
    lastLogin: '2025-06-24',
  },
  {
    id: 'user2',
    name: 'Jane Doe',
    email: 'jane.doe@example.com',
    role: 'admin',
    status: 'active',
    lastLogin: '2025-06-23',
  },
  {
    id: 'user3',
    name: 'John Smith',
    email: 'john.smith@example.com',
    role: 'client',
    status: 'active',
    lastLogin: '2025-06-22',
  },
  {
    id: 'user4',
    name: 'Agent A',
    email: 'agent.a@example.com',
    role: 'agent',
    status: 'active',
    lastLogin: '2025-06-21',
  },
  {
    id: 'user5',
    name: 'Client B',
    email: 'client.b@example.com',
    role: 'client',
    status: 'inactive',
    lastLogin: '2025-06-15',
  },
];

const mockRoles = [
  {
    id: 'super_admin',
    name: 'Super Admin',
    description: 'Full access to all features and settings.',
  },
  {
    id: 'admin',
    name: 'Admin',
    description: 'Manages users, content, and system settings.',
  },
  {
    id: 'client',
    name: 'Client',
    description: 'Accesses dashboard, projects, and feedback.',
  },
  {
    id: 'agent',
    name: 'Agent',
    description: 'Manages specific client tasks and communications.',
  },
];

const mockPermissions = {
  super_admin: {
    dashboard: true,
    blog_manage: true,
    calendar_manage: true,
    tasks_manage: true,
    reminders_manage: true,
    profile_manage: true,
    user_manage: true,
    agent_access: true,
    ollama_access: true,
    linktree_manage: true,
    alnajah_access: true,
    roles_manage: true,
    permissions_manage: true,
  },
  admin: {
    dashboard: true,
    blog_manage: true,
    calendar_manage: true,
    tasks_manage: true,
    reminders_manage: true,
    profile_manage: true,
    user_manage: true,
    agent_access: true,
    ollama_access: true,
    linktree_manage: true,
    alnajah_access: true,
    roles_manage: false,
    permissions_manage: false,
  },
  client: {
    dashboard: true,
    blog_manage: false,
    calendar_manage: true,
    tasks_manage: true,
    reminders_manage: true,
    profile_manage: true,
    user_manage: false,
    agent_access: false,
    ollama_access: true,
    linktree_manage: false,
    alnajah_access: true,
    roles_manage: false,
    permissions_manage: false,
  },
  agent: {
    dashboard: true,
    blog_manage: false,
    calendar_manage: true,
    tasks_manage: true,
    reminders_manage: true,
    profile_manage: true,
    user_manage: false,
    agent_access: true,
    ollama_access: true,
    linktree_manage: false,
    alnajah_access: true,
    roles_manage: false,
    permissions_manage: false,
  },
};

const UserManagement = () => {
  const [users, setUsers] = useState(mockUsers);
  const [roles, setRoles] = useState(mockRoles);
  const [permissions, setPermissions] = useState(mockPermissions);
  const [activeTab, setActiveTab] = useState('users');
  const [editingUser, setEditingUser] = useState(null);
  const [editingRole, setEditingRole] = useState(null);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // eslint-disable-next-line no-unused-vars
  const { currentUser } = useAuth(); // Marked as unused, keeping for potential future logic
  const { profile } = useProfile();

  const currentRole = profile?.role || 'client';
  const isSuperAdmin = currentRole === 'super_admin';

  useEffect(() => {
    const timer = setTimeout(() => {
      setMessage('Data loaded from mock backend.');
      setMessageType('success');
      setTimeout(() => setMessage(''), 3000);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  // --- User Management Handlers ---
  const handleEditUser = (user) => {
    setEditingUser({ ...user });
  };

  const handleSaveUser = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setUsers(users.map((u) => (u.id === editingUser.id ? editingUser : u)));
    setEditingUser(null);
    setIsSaving(false);
    showMessage('User updated successfully!', 'success');
  };

  const handleDeleteUser = async (userId) => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setUsers(users.filter((u) => u.id !== userId));
    setIsSaving(false);
    showMessage('User deleted successfully!', 'success');
  };

  // --- Role Management Handlers ---
  const handleEditRole = (role) => {
    setEditingRole({ ...role });
  };

  const handleSaveRole = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setRoles(roles.map((r) => (r.id === editingRole.id ? editingRole : r)));
    setEditingRole(null);
    setIsSaving(false);
    showMessage('Role updated successfully!', 'success');
  };

  const handleAddRole = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    const newRoleId = `role${Date.now()}`;
    const newRole = {
      id: newRoleId,
      name: 'New Role',
      description: 'Description for new role.',
    };
    setRoles([...roles, newRole]);
    setPermissions((prev) => ({ ...prev, [newRoleId]: {} }));
    setIsSaving(false);
    showMessage('New role added!', 'success');
  };

  // --- Permission Management Handlers ---
  const handlePermissionToggle = (roleId, permissionKey) => {
    setPermissions((prev) => ({
      ...prev,
      [roleId]: {
        ...prev[roleId],
        [permissionKey]: !prev[roleId][permissionKey],
      },
    }));
  };

  const handleSavePermissions = async () => {
    setIsSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsSaving(false);
    showMessage('Permissions updated successfully!', 'success');
  };

  if (!isSuperAdmin) {
    return (
      <div className="p-6 md:p-8 bg-black-ops min-h-screen flex items-center justify-center">
        <motion.div
          className="glass-effect p-8 rounded-xl text-center text-off-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <FaBan className="text-red-500 text-6xl mb-4" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-light-gray">
            You do not have sufficient permissions to view this page.
          </p>
          <p className="text-sm text-mid-gray mt-2">
            Please contact your administrator if you believe this is an error.
          </p>
        </motion.div>
      </div>
    );
  }

  const allPermissionKeys = Object.keys(Object.values(permissions)[0] || {});

  return (
    <motion.div
      className="p-6 md:p-8 bg-black-ops min-h-screen flex flex-col"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-4xl font-bold text-off-white mb-8">
        Admin Settings & Management
      </h1>

      {message && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={`p-3 mb-4 rounded-md text-sm ${
            messageType === 'success'
              ? 'bg-green-700/30 text-green-300 border border-green-500'
              : 'bg-red-700/30 text-red-300 border border-red-500'
          }`}
        >
          {message}
        </motion.div>
      )}

      <div className="flex space-x-4 mb-6 border-b border-mid-gray pb-2">
        <button
          onClick={() => setActiveTab('users')}
          className={`text-lg font-semibold py-2 px-4 rounded-t-lg transition-colors ${activeTab === 'users' ? 'bg-mid-gray text-teal-300 border-b-2 border-teal-500' : 'text-light-gray hover:text-off-white'}`}
        >
          <FaUsers className="inline-block mr-2" /> Users
        </button>
        <button
          onClick={() => setActiveTab('roles')}
          className={`text-lg font-semibold py-2 px-4 rounded-t-lg transition-colors ${activeTab === 'roles' ? 'bg-mid-gray text-teal-300 border-b-2 border-teal-500' : 'text-light-gray hover:text-off-white'}`}
        >
          <FaUserCog className="inline-block mr-2" /> Roles
        </button>
        <button
          onClick={() => setActiveTab('permissions')}
          className={`text-lg font-semibold py-2 px-4 rounded-t-lg transition-colors ${activeTab === 'permissions' ? 'bg-mid-gray text-teal-300 border-b-2 border-teal-500' : 'text-light-gray hover:text-off-white'}`}
        >
          <FaUnlockAlt className="inline-block mr-2" /> Permissions
        </button>
      </div>

      <div className="flex-grow glass-effect p-6 rounded-xl shadow-lg border border-mid-gray overflow-hidden">
        {/* User Management Tab */}
        {activeTab === 'users' && (
          <motion.div
            key="users-tab"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="h-full flex flex-col"
          >
            <h2 className="text-3xl font-bold text-off-white mb-6">
              User Accounts
            </h2>
            <div className="overflow-x-auto custom-scrollbar flex-grow">
              <table className="min-w-full bg-dark-gray/50 rounded-lg overflow-hidden">
                <thead className="bg-mid-gray text-light-gray uppercase text-sm">
                  <tr>
                    <th className="py-3 px-4 text-left">Name</th>
                    <th className="py-3 px-4 text-left">Email</th>
                    <th className="py-3 px-4 text-left">Role</th>
                    <th className="py-3 px-4 text-left">Status</th>
                    <th className="py-3 px-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence>
                    {users.map((user) => (
                      <motion.tr
                        key={user.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -50 }}
                        transition={{ duration: 0.3 }}
                        className="border-b border-mid-gray last:border-b-0 hover:bg-dark-gray/70"
                      >
                        <td className="py-3 px-4 text-off-white">
                          {user.name}
                        </td>
                        <td className="py-3 px-4 text-light-gray">
                          {user.email}
                        </td>
                        <td className="py-3 px-4">
                          {editingUser?.id === user.id ? (
                            <select
                              value={editingUser.role}
                              onChange={(e) =>
                                setEditingUser({
                                  ...editingUser,
                                  role: e.target.value,
                                })
                              }
                              className="bg-mid-gray border border-dark-gray rounded-md p-1 text-light-gray text-sm"
                            >
                              {roles.map((role) => (
                                <option key={role.id} value={role.id}>
                                  {role.name}
                                </option>
                              ))}
                            </select>
                          ) : (
                            <span className="text-cyan-300 font-medium">
                              {roles.find((r) => r.id === user.role)?.name ||
                                user.role}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {editingUser?.id === user.id ? (
                            <select
                              value={editingUser.status}
                              onChange={(e) =>
                                setEditingUser({
                                  ...editingUser,
                                  status: e.target.value,
                                })
                              }
                              className="bg-mid-gray border border-dark-gray rounded-md p-1 text-light-gray text-sm"
                            >
                              <option value="active">Active</option>
                              <option value="inactive">Inactive</option>
                            </select>
                          ) : (
                            <span
                              className={`font-medium ${user.status === 'active' ? 'text-green-400' : 'text-red-400'}`}
                            >
                              {user.status.charAt(0).toUpperCase() +
                                user.status.slice(1)}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 flex items-center space-x-2">
                          {editingUser?.id === user.id ? (
                            <>
                              <motion.button
                                onClick={handleSaveUser}
                                disabled={isSaving}
                                className="btn-primary bg-green-600 hover:bg-green-700 text-off-white p-2 rounded-full"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                {isSaving ? (
                                  <FaSpinner className="animate-spin" />
                                ) : (
                                  <FaCheckCircle />
                                )}
                              </motion.button>
                              <motion.button
                                onClick={() => setEditingUser(null)}
                                className="btn-primary bg-red-600 hover:bg-red-700 text-off-white p-2 rounded-full"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                <FaTimesCircle />
                              </motion.button>
                            </>
                          ) : (
                            <>
                              <motion.button
                                onClick={() => handleEditUser(user)}
                                className="btn-primary bg-teal-600 hover:bg-teal-700 text-off-white p-2 rounded-full"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                <FaEdit />
                              </motion.button>
                              <motion.button
                                onClick={() => handleDeleteUser(user.id)}
                                className="btn-primary bg-red-600 hover:bg-red-700 text-off-white p-2 rounded-full"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                <FaTrash />
                              </motion.button>
                            </>
                          )}
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Role Management Tab */}
        {activeTab === 'roles' && (
          <motion.div
            key="roles-tab"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="h-full flex flex-col"
          >
            <h2 className="text-3xl font-bold text-off-white mb-6">
              Roles Configuration
            </h2>
            <motion.button
              onClick={handleAddRole}
              className="btn-action mb-6 self-start"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaPlus className="mr-2" /> Add New Role
            </motion.button>
            <div className="overflow-x-auto custom-scrollbar flex-grow">
              <table className="min-w-full bg-dark-gray/50 rounded-lg overflow-hidden">
                <thead className="bg-mid-gray text-light-gray uppercase text-sm">
                  <tr>
                    <th className="py-3 px-4 text-left">Role Name</th>
                    <th className="py-3 px-4 text-left">Description</th>
                    <th className="py-3 px-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence>
                    {roles.map((role) => (
                      <motion.tr
                        key={role.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -50 }}
                        transition={{ duration: 0.3 }}
                        className="border-b border-mid-gray last:border-b-0 hover:bg-dark-gray/70"
                      >
                        <td className="py-3 px-4">
                          {editingRole?.id === role.id ? (
                            <input
                              type="text"
                              value={editingRole.name}
                              onChange={(e) =>
                                setEditingRole({
                                  ...editingRole,
                                  name: e.target.value,
                                })
                              }
                              className="bg-mid-gray border border-dark-gray rounded-md p-1 text-light-gray text-sm"
                            />
                          ) : (
                            <span className="text-off-white font-medium">
                              {role.name}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {editingRole?.id === role.id ? (
                            <input
                              type="text"
                              value={editingRole.description}
                              onChange={(e) =>
                                setEditingRole({
                                  ...editingRole,
                                  description: e.target.value,
                                })
                              }
                              className="bg-mid-gray border border-dark-gray rounded-md p-1 text-light-gray text-sm"
                            />
                          ) : (
                            <span className="text-light-gray text-sm">
                              {role.description}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 flex items-center space-x-2">
                          {editingRole?.id === role.id ? (
                            <>
                              <motion.button
                                onClick={handleSaveRole}
                                disabled={isSaving}
                                className="btn-primary bg-green-600 hover:bg-green-700 text-off-white p-2 rounded-full"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                {isSaving ? (
                                  <FaSpinner className="animate-spin" />
                                ) : (
                                  <FaCheckCircle />
                                )}
                              </motion.button>
                              <motion.button
                                onClick={() => setEditingRole(null)}
                                className="btn-primary bg-red-600 hover:bg-red-700 text-off-white p-2 rounded-full"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                              >
                                <FaTimesCircle />
                              </motion.button>
                            </>
                          ) : (
                            <motion.button
                              onClick={() => handleEditRole(role)}
                              className="btn-primary bg-teal-600 hover:bg-teal-700 text-off-white p-2 rounded-full"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                            >
                              <FaEdit />
                            </motion.button>
                          )}
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Permissions Management Tab */}
        {activeTab === 'permissions' && (
          <motion.div
            key="permissions-tab"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="h-full flex flex-col"
          >
            <h2 className="text-3xl font-bold text-off-white mb-6">
              Permission Customization
            </h2>
            <div className="overflow-x-auto custom-scrollbar flex-grow">
              <table className="min-w-full bg-dark-gray/50 rounded-lg overflow-hidden">
                <thead className="bg-mid-gray text-light-gray uppercase text-sm">
                  <tr>
                    <th className="py-3 px-4 text-left">
                      Feature / Permission
                    </th>
                    {roles.map((role) => (
                      <th key={role.id} className="py-3 px-4 text-center">
                        {role.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {allPermissionKeys.length > 0 ? (
                    allPermissionKeys.map((key) => (
                      <tr
                        key={key}
                        className="border-b border-mid-gray last:border-b-0 hover:bg-dark-gray/70"
                      >
                        <td className="py-3 px-4 text-off-white font-medium capitalize">
                          {key.replace(/_/g, ' ')}
                        </td>
                        {roles.map((role) => (
                          <td
                            key={`${role.id}-${key}`}
                            className="py-3 px-4 text-center"
                          >
                            <AnimatedToggleSwitch
                              checked={!!permissions[role.id]?.[key]}
                              onChange={() =>
                                handlePermissionToggle(role.id, key)
                              }
                              disabled={
                                role.id === 'super_admin' &&
                                permissions[role.id]?.[key]
                              }
                            />
                          </td>
                        ))}
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan={roles.length + 1}
                        className="py-4 text-center text-light-gray"
                      >
                        No permissions defined.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <motion.button
              onClick={handleSavePermissions}
              disabled={isSaving}
              className="btn-action mt-6 self-end"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isSaving ? (
                <FaSpinner className="animate-spin mr-2" />
              ) : (
                <FaSave className="mr-2" />
              )}{' '}
              Save Permissions
            </motion.button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

UserManagement.propTypes = {
  roles: PropTypes.array,
};

export default UserManagement;
