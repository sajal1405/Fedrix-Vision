// src/components/common/Header.jsx
import React, { useState, useRef, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { FaBars, FaBell } from 'react-icons/fa';
// eslint-disable-next-line no-unused-vars
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../context/AuthContext';
import { useUserProfile } from '../../context/UserProfileContext';
import UserProfileDropdown from './UserProfileDropdown';
import { useSidebar } from '../../context/SidebarContext';

const Header = () => {
  const { signOut, currentUser } = useAuth();
  const { userProfile } = useUserProfile();
  const { toggleSidebar } = useSidebar();
  const navigate = useNavigate();

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const avatarRef = useRef(null);

  // Function to get a dynamic greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  // Get current date in a friendly format
  const getCurrentDate = () => {
    const options = { weekday: 'short', month: 'short', day: 'numeric' }; // Abbreviated for header space
    return new Date().toLocaleDateString(undefined, options);
  };

  // Determine the name to display and avatar URL
  const displayName = userProfile?.full_name || currentUser?.email?.split('@')[0] || 'Agent';
  const displayAvatar = userProfile?.avatar_url || 'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR';
  const displayRole = userProfile?.role
    ? userProfile.role.charAt(0).toUpperCase() + userProfile.role.slice(1)
    : 'User'; // Capitalize role for display


  const handleSignOut = async () => {
    const { success } = await signOut();
    if (success) {
      navigate('/login');
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        avatarRef.current &&
        !avatarRef.current.contains(event.target)
      ) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 120, damping: 14, delay: 0.1 }}
      className="fixed top-0 left-0 w-full lg:pl-64 bg-dark-gray shadow-lg z-30 border-b border-mid-gray"
    >
      <div className="container mx-auto px-4 py-3 flex justify-between items-center h-16">
        {/* Left side: Mobile toggle, Greeting, and Date */}
        <div className="flex items-center">
          <button
            onClick={toggleSidebar}
            className="lg:hidden text-light-gray hover:text-white mr-4 p-2 rounded-md hover:bg-mid-gray transition-colors"
            aria-label="Toggle sidebar"
          >
            <FaBars className="text-xl" />
          </button>
          <NavLink to="/dashboard" className="text-white text-2xl font-bold hidden md:block">
            Fedrix Vision
          </NavLink>
          <div className="flex flex-col md:flex-row md:items-center ml-4">
            <h1 className="text-xl font-bold text-white leading-none">
              {getGreeting()}, <span className="text-teal-400">{displayName}</span>
            </h1>
            <p className="text-sm text-light-gray mt-1 md:mt-0 md:ml-3">
              {getCurrentDate()}
            </p>
          </div>
        </div>

        {/* Right side: Notifications and User Profile */}
        <div className="flex items-center space-x-4">
          <button className="text-light-gray hover:text-white p-2 rounded-md hover:bg-mid-gray transition-colors">
            <FaBell className="text-xl" />
          </button>

          <div className="relative">
            <button
              ref={avatarRef}
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center space-x-2 text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-500 rounded-full pr-2"
              aria-haspopup="true"
              aria-expanded={isDropdownOpen}
            >
              <img
                src={displayAvatar}
                alt="User Avatar"
                className="w-10 h-10 rounded-full object-cover border-2 border-teal-500"
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = 'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR';
                }}
              />
              <div className="hidden md:flex flex-col items-start"> {/* Use flex-col for name and role */}
                <span>{displayName}</span>
                <span className="text-xs font-normal text-teal-300 px-2 py-0.5 bg-teal-800/30 rounded-full">{displayRole}</span>
              </div>
            </button>

            <AnimatePresence>
              {isDropdownOpen && (
                <UserProfileDropdown signOut={handleSignOut} onClose={() => setIsDropdownOpen(false)} />
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
