// src/components/common/Footer.js
// This component renders a simple footer for the application.
// It displays copyright information and a link to the developer's website.
import React from 'react';

const Footer = () => {
  return (
    <footer className="w-full text-center p-4 bg-black/50 border-t border-white/10 text-white/50 text-sm relative z-10">
      <span>
        Made with <span className="text-red-500">❤</span> by{' '}
        <a
          href="https://fedrixgroup.com"
          target="_blank"
          rel="noreferrer"
          className="text-purple-400 hover:text-purple-300 font-semibold transition-colors"
        >
          Fedrix MediaLab
        </a>
      </span>
      <p className="mt-1">
        &copy; {new Date().getFullYear()} Fedrix Vision. All rights reserved.
      </p>
    </footer>
  );
};

export default Footer;
