// src/components/common/GlobalFooter.jsx
import React from 'react';
import { motion } from 'framer-motion';

const GlobalFooter = () => {
  return (
    <motion.footer
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.8 }}
      className="w-full bg-dark-gray/80 text-light-gray text-center p-3 text-sm border-t border-mid-gray z-20"
    >
      <p>
        &copy; {new Date().getFullYear()} Fedrix Medialab. All rights reserved.
      </p>
    </motion.footer>
  );
};

export default GlobalFooter;
