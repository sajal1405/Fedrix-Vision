// src/components/common/ErrorBoundary.jsx
import React from 'react';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types'; // Added PropTypes import to resolve error

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <motion.div
          className="flex flex-col items-center justify-center min-h-screen bg-black-ops text-off-white p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div
            className="glass-effect p-8 rounded-xl shadow-lg border border-mid-gray text-center max-w-lg w-full"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 100 }}
          >
            <h1 className="text-4xl font-bold mb-4 text-red-400">
              Oops! Something went wrong.
            </h1>
            <p className="text-lg text-light-gray mb-6">
              We&apos;re sorry, but an unexpected error has occurred.
            </p>
            {this.state.error && (
              <details className="text-sm text-mid-gray text-left bg-dark-gray/50 p-4 rounded-lg overflow-auto max-h-60 mb-4">
                <summary className="font-semibold cursor-pointer text-teal-300">
                  Error Details
                </summary>
                <pre className="whitespace-pre-wrap break-words mt-2">
                  {this.state.error.toString()}
                  <br />
                  {this.state.errorInfo?.componentStack}
                </pre>
              </details>
            )}
            <button
              onClick={() => window.location.reload()}
              className="btn-action mt-4 px-6 py-3"
            >
              Reload Page
            </button>
            <p className="text-mid-gray text-sm mt-4">
              If the problem persists, please contact support.
            </p>
          </motion.div>
        </motion.div>
      );
    }

    return this.props.children;
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.node.isRequired,
};

export default ErrorBoundary;
