// src/components/common/AnimatedBackground.jsx
import React, { useRef, useEffect } from 'react';

const AnimatedBackground = () => {
  const canvasRef = useRef(null);
  const animationFrameId = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    // Adjust canvas size on window resize
    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };
    window.addEventListener('resize', handleResize);

    // Particle class for the background animation
    class Particle {
      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 0.5; // Very slow horizontal movement
        this.vy = (Math.random() - 0.5) * 0.5; // Very slow vertical movement
        this.radius = Math.random() * 1.5; // Small particles
        this.alpha = Math.random() * 0.7; // Semi-transparent
        this.color = 'rgba(200, 200, 200,'; // Light gray for subtle contrast
      }

      // Update particle position
      update() {
        this.x += this.vx;
        this.y += this.vy;

        // Wrap around screen edges
        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;
      }

      // Draw particle
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color + this.alpha + ')';
        ctx.fill();
      }
    }

    const particles = [];
    const numParticles = 100; // Number of particles

    // Create particles
    for (let i = 0; i < numParticles; i++) {
      particles.push(new Particle());
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, width, height); // Clear canvas
      ctx.fillStyle = 'rgba(26, 26, 26, 0.1)'; // Slight dark overlay for trail effect, matching black-ops
      ctx.fillRect(0, 0, width, height);

      particles.forEach((p) => {
        p.update();
        p.draw();
      });

      animationFrameId.current = requestAnimationFrame(animate);
    };

    animate(); // Start the animation

    // Cleanup function
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-0" // Position absolutely to fill parent and stay behind content
      style={{
        backgroundColor: '#1a1a1a', // Fallback background color, matching black-ops
        filter: 'brightness(0.8) contrast(1.2)', // Subtle enhancement for particles
      }}
    />
  );
};

export default AnimatedBackground;
