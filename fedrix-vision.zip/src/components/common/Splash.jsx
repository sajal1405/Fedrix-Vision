// src/components/common/Splash.jsx
// This component renders an initial splash screen with a brand name and a loading indicator.
// It's designed to be displayed briefly when the application first loads,
// providing a smoother user experience before the main content appears.
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types'; // For type-checking component props
import { motion } from 'framer-motion'; // For animations

const Splash = ({ onComplete }) => {
  const [done, setDone] = useState(false); // State to control the splash screen's fading animation

  useEffect(() => {
    // Set a timer to hide the splash screen after a delay.
    // The delay should be sufficient for initial app loading or a desired brand reveal.
    const timer = setTimeout(() => {
      setDone(true); // Trigger the fade-out animation
      // After a short delay to allow fade-out animation to complete,
      // call the onComplete callback to signal the parent component to hide this splash component.
      setTimeout(() => onComplete(), 1000); // 1 second for fade-out transition
    }, 2200); // 2.2 seconds initial display time

    // Cleanup function: Clear the timer if the component unmounts prematurely
    // (e.g., if navigation occurs very quickly).
    return () => clearTimeout(timer);
  }, [onComplete]); // Dependency array: re-run effect if onComplete callback changes

  return (
    <motion.div
      className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center"
      // Animation for the splash screen container to fade out
      initial={{ opacity: 1 }}
      animate={{ opacity: done ? 0 : 1 }} // Fade out when 'done' is true
      transition={{ duration: 1 }} // Duration of the fade animation
    >
      <motion.div
        className="text-white text-3xl font-bold tracking-widest"
        // Animation for the brand name (scale up and fade in)
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: 'spring', duration: 1 }} // Spring animation for a lively effect
      >
        Fedrix Vision
      </motion.div>
      {/* Simple animated loading bar */}
      <div className="mt-6 w-32 h-1 rounded-full bg-gray-700 animate-pulse" />
    </motion.div>
  );
};

// PropTypes for the Splash component to ensure 'onComplete' is a function
Splash.propTypes = {
  onComplete: PropTypes.func.isRequired, // Callback function to be called when the splash animation completes
};

export default Splash;
