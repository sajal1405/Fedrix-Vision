// src/components/common/UserMenu.jsx
import React from 'react';
// import { useContext } from 'react'; // Removed unused useContext
import PropTypes from 'prop-types';

const UserMenu = ({ user }) => {
  return (
    <div className="flex items-center space-x-2 text-off-white">
      <img
        src={user.avatarUrl}
        alt="User Avatar"
        className="w-8 h-8 rounded-full"
      />
      <span>Hello, {user.name}</span>
    </div>
  );
};

UserMenu.propTypes = {
  user: PropTypes.shape({
    name: PropTypes.string.isRequired,
    avatarUrl: PropTypes.string.isRequired,
  }).isRequired,
};

export default UserMenu;
