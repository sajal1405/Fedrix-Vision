// src/components/common/Sidebar.jsx
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  FaHome,
  FaCog,
  FaRobot,
  FaUsers,
  FaFolderOpen,
  FaCalendarAlt,
  FaTimes,
} from 'react-icons/fa'; // FaSignOutAlt removed
import { NavLink } from 'react-router-dom'; // useNavigate and useAuth not needed here for logout
import { useUserProfile } from '../../context/UserProfileContext';
import { useSidebar } from '../../context/SidebarContext';

import FedrixLogo from '../../assets/fedrix.svg';

const Sidebar = () => {
  // Removed signOut, navigate, useAuth as logout button is moved
  const { userProfile } = useUserProfile();
  const { isSidebarOpen, toggleSidebar, closeSidebar } = useSidebar();

  const [logoError, setLogoError] = useState(false);

  // Removed handleSignOut function as it's no longer in sidebar

  const navItems = [
    {
      name: 'Dashboard',
      icon: FaHome,
      path: '/dashboard',
      roles: ['user', 'admin'],
    },
    {
      name: 'Agent Chat',
      icon: FaRobot,
      path: '/ollama',
      roles: ['user', 'admin'],
    },
    {
      name: 'Projects',
      icon: FaFolderOpen,
      path: '/projects',
      roles: ['user', 'admin'],
    },
    {
      name: 'Calendar',
      icon: FaCalendarAlt,
      path: '/calendar',
      roles: ['user', 'admin'],
    },
    { name: 'Admin Panel', icon: FaUsers, path: '/admin', roles: ['admin'] },
    {
      name: 'Settings',
      icon: FaCog,
      path: '/settings',
      roles: ['user', 'admin'],
    },
  ];

  const filteredNavItems = navItems.filter((item) =>
    item.roles.includes(userProfile?.role || 'user'),
  );

  return (
    <motion.div
      initial={false}
      animate={{ width: isSidebarOpen ? '256px' : '80px' }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="bg-dark-gray shadow-2xl border-r border-mid-gray flex-shrink-0 h-screen overflow-y-auto custom-scrollbar
                 fixed left-0 top-0 z-40 flex flex-col"
    >
      <div className="p-4 flex items-center justify-between">
        {isSidebarOpen ? (
          logoError ? (
            <h1 className="text-2xl font-bold text-teal-400">Fedrix</h1>
          ) : (
            <img
              src={FedrixLogo}
              alt="Fedrix Logo"
              className="h-8 w-auto"
              onError={() => setLogoError(true)}
            />
          )
        ) : (
          <h1 className="text-2xl font-bold text-teal-400">FX</h1>
        )}
        <button
          onClick={toggleSidebar}
          className="lg:hidden text-light-gray hover:text-white transition-colors p-2 rounded-full hover:bg-mid-gray"
          aria-label="Toggle sidebar"
        >
          <FaTimes />
        </button>
      </div>

      <nav className="flex-grow mt-8">
        <ul className="space-y-2">
          {filteredNavItems.map((item) => (
            <li key={item.name}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center py-2 px-4 rounded-lg transition-colors duration-200
                   ${isSidebarOpen ? '' : 'justify-center'}
                   ${
                     isActive
                       ? 'bg-teal-700/60 text-white shadow-md'
                       : 'text-light-gray hover:bg-mid-gray/50 hover:text-white'
                   }`
                }
                onClick={closeSidebar}
              >
                <item.icon
                  className={`text-xl ${isSidebarOpen ? 'mr-3' : ''}`}
                />
                {isSidebarOpen && (
                  <span className="font-medium text-lg">{item.name}</span>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      {/* The logout button is intentionally removed from here. */}
      {/* It now lives exclusively in the Header's user profile dropdown. */}
    </motion.div>
  );
};

// PropTypes are now correctly absent since they were removed with the signOut button.
// If you added back any other props, remember to add their PropTypes back.

export default Sidebar;
