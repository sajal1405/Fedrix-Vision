// src/components/common/UserProfileDropdown.jsx
import React, { useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { motion } from 'framer-motion';
import {
  FaUserCircle,
  FaSignOutAlt,
  FaCog,
  FaQuestionCircle,
  FaChartLine,
  FaRobot,
} from 'react-icons/fa';
import { NavLink } from 'react-router-dom';
import { useUserProfile } from '../../context/UserProfileContext';

const UserProfileDropdown = ({ signOut, onClose }) => {
  const dropdownRef = useRef(null);
  const { userProfile, isLoadingProfile, profileError } = useUserProfile();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  // Handle logout
  const handleSignOut = () => {
    signOut(); // This calls the signOut function passed from Header.jsx
    onClose();
  };

  if (isLoadingProfile) {
    return (
      <div className="absolute right-0 mt-2 w-64 bg-dark-gray border border-mid-gray rounded-lg shadow-xl p-4 text-sm text-white/90 z-40">
        Loading profile...
      </div>
    );
  }

  if (profileError) {
    return (
      <div className="absolute right-0 mt-2 w-64 bg-dark-gray border border-mid-gray rounded-lg shadow-xl p-4 text-sm text-red-400 z-40">
        Error loading profile.
      </div>
    );
  }

  const displayName = userProfile?.full_name || userProfile?.email || 'User';
  const displayRole = userProfile?.role
    ? userProfile.role.charAt(0).toUpperCase() + userProfile.role.slice(1)
    : 'User'; // Capitalize role

  return (
    <motion.div
      ref={dropdownRef}
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="absolute right-0 mt-2 w-64 bg-dark-gray border border-mid-gray rounded-lg shadow-xl p-4 text-sm text-white/90 z-40"
    >
      <div className="flex items-center border-b border-mid-gray pb-3 mb-3">
        <img
          src={
            userProfile?.avatar_url ||
            'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR'
          }
          alt="User Avatar"
          className="w-12 h-12 rounded-full object-cover border-2 border-teal-500 mr-3"
          onError={(e) => {
            e.target.onerror = null;
            e.target.src = 'https://placehold.co/150/00bf8b/FFFFFF?text=AVATAR';
          }}
        />
        <div>
          <p className="font-bold text-white">{displayName}</p>
          <p className="text-teal-400 text-xs">{displayRole}</p>
        </div>
      </div>

      {/* Profile Link */}
      <NavLink
        to="/profile"
        className="flex items-center p-2 rounded-md hover:bg-mid-gray transition-colors mb-1 text-white/90"
        onClick={onClose}
      >
        <FaUserCircle className="mr-3" /> My Profile
      </NavLink>

      {/* Settings Link */}
      <NavLink
        to="/settings"
        className="flex items-center p-2 rounded-md hover:bg-mid-gray transition-colors mb-1 text-white/90"
        onClick={onClose}
      >
        <FaCog className="mr-3" /> Settings
      </NavLink>

      {/* Conditional Links based on role */}
      {userProfile?.role === 'admin' && (
        <NavLink
          to="/admin-dashboard" // Example admin route
          className="flex items-center p-2 rounded-md hover:bg-mid-gray transition-colors mb-1 text-white/90"
          onClick={onClose}
        >
          <FaChartLine className="mr-3" /> Admin Dashboard
        </NavLink>
      )}

      {/* Ollama Dashboard Link */}
      <NavLink
        to="/ollama"
        className="flex items-center p-2 rounded-md hover:bg-mid-gray transition-colors mb-1 text-white/90"
        onClick={onClose}
      >
        <FaRobot className="mr-3" /> Agent Chat
      </NavLink>

      <NavLink
        to="/help" // Example help route
        className="flex items-center p-2 rounded-md hover:bg-mid-gray transition-colors mb-1 text-white/90"
        onClick={onClose}
      >
        <FaQuestionCircle className="mr-3" /> Help & Support
      </NavLink>

      {/* Sign Out */}
      <button
        onClick={handleSignOut}
        className="flex items-center w-full p-2 rounded-md bg-red-600 hover:bg-red-700 text-white mt-3 transition-colors"
      >
        <FaSignOutAlt className="mr-3" /> Sign Out
      </button>
    </motion.div>
  );
};

UserProfileDropdown.propTypes = {
  signOut: PropTypes.func.isRequired,
  onClose: PropTypes.func.isRequired,
};

export default UserProfileDropdown;
