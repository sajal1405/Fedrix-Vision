// src/components/common/Footer.jsx
import React from 'react';
import { FaGithub, FaLinkedin, FaTwitter } from 'react-icons/fa'; // Example social icons

const Footer = () => {
  return (
    <footer className="w-full bg-dark-gray text-light-gray py-2 px-6 border-t border-mid-gray text-center text-sm flex flex-col sm:flex-row items-center justify-between z-10 flex-shrink-0">
      <p className="mb-2 sm:mb-0">
        &copy; {new Date().getFullYear()} Fedrix Vision. All rights reserved.
      </p>
      <div className="flex space-x-4">
        <a
          href="https://github.com/fedrix-vision"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-teal-400 transition-colors"
        >
          <FaGithub className="w-5 h-5" />
        </a>
        <a
          href="https://linkedin.com/company/fedrix-vision"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-teal-400 transition-colors"
        >
          <FaLinkedin className="w-5 h-5" />
        </a>
        <a
          href="https://twitter.com/fedrix_vision"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:text-teal-400 transition-colors"
        >
          <FaTwitter className="w-5 h-5" />
        </a>
      </div>
    </footer>
  );
};

export default Footer;
