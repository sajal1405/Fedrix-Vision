// src/components/ai/AgentDashboard.jsx
// This component provides an interface for interacting with an AI agent
// to generate content. It uses the `AgentAIContext` for AI logic.
import React, { useContext, useState } from 'react';
import { AgentAIContext } from '../../context/AgentAIContext'; // Context for AI generation functions
import { motion } from 'framer-motion'; // For animations
import { FaPaperPlane, FaSpinner } from 'react-icons/fa'; // Icons

const AgentDashboard = () => {
  // Destructure values from AgentAIContext
  const { generated, generateContent, loading } = useContext(AgentAIContext);
  const [prompt, setPrompt] = useState(''); // State to hold the user's input prompt

  /**
   * Handles the click event to trigger content generation.
   * Calls the `generateContent` function from the context with the current prompt.
   */
  const handleGenerate = () => {
    if (prompt.trim()) {
      // Only generate if prompt is not empty
      generateContent(prompt);
    }
  };

  return (
    <motion.div
      className="p-6 bg-black/20 rounded-xl border border-white/10 shadow-lg min-h-[calc(100vh-180px)] flex flex-col"
      initial={{ opacity: 0, y: 10 }} // Initial animation state
      animate={{ opacity: 1, y: 0 }} // Animation to visible position
      transition={{ duration: 0.5 }} // Animation duration
    >
      <h2 className="text-white text-2xl font-bold mb-4">🤖 AI Agent</h2>

      {/* Input section for the AI prompt */}
      <div className="mb-6 flex-grow flex flex-col">
        <label htmlFor="ai-prompt" className="block text-white/70 text-sm mb-2">
          Enter your prompt for the AI:
        </label>
        <textarea
          id="ai-prompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., 'Write a short marketing blurb for a new car wash service focusing on eco-friendliness.'"
          rows="8"
          className="email-input flex-grow custom-scrollbar"
          disabled={loading} // Disable input while AI is generating
        />
        <button
          onClick={handleGenerate}
          disabled={loading || !prompt.trim()} // Disable button if loading or prompt is empty
          className="btn-action mt-4 self-end flex items-center gap-2 px-6 py-3"
        >
          {loading ? (
            <>
              <FaSpinner className="animate-spin" /> Generating...
            </>
          ) : (
            <>
              <FaPaperPlane /> Generate Content
            </>
          )}
        </button>
      </div>

      {/* Display section for generated AI content */}
      <div className="bg-white/5 p-4 rounded-lg border border-white/10 flex-grow max-h-96 overflow-y-auto custom-scrollbar">
        <h3 className="text-white/70 text-sm mb-2">Generated Content:</h3>
        {loading ? (
          <p className="text-white/60 animate-pulse-light">AI is thinking...</p>
        ) : generated ? (
          <p
            data-testid="generated-content"
            className="text-white text-base whitespace-pre-wrap break-words"
          >
            {generated}
          </p>
        ) : (
          <p className="text-white/60">
            Your AI-generated content will appear here.
          </p>
        )}
      </div>
    </motion.div>
  );
};

export default AgentDashboard;
