// File: D:/FedrixVision/src/components/analytics/AnalyticsPanel.jsx

import React, { useEffect, useState } from 'react';
import LogsViewer from './LogsViewer';
import { motion } from 'framer-motion';

const AnalyticsPanel = () => {
  const [logData, setLogData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/logs/cms-logs.json')
      .then((res) => res.json())
      .then((data) => {
        setLogData(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Log fetch failed:', err);
        setLoading(false);
      });
  }, []);

  return (
    <motion.div
      className="p-6 text-white"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h1 className="text-2xl font-bold mb-4">📊 Al Najah CMS Analytics</h1>
      {loading ? <p>Loading logs...</p> : <LogsViewer logs={logData} />}
    </motion.div>
  );
};

export default AnalyticsPanel;
