// File: D:/FedrixVision/src/components/analytics/LogsViewer.jsx

import React from 'react';
import PropTypes from 'prop-types';

const LogsViewer = ({ logs }) => {
  return (
    <div className="overflow-x-auto bg-white/5 border border-white/10 rounded-xl p-4">
      <table className="min-w-full text-sm text-white">
        <thead>
          <tr className="border-b border-white/10">
            <th className="text-left py-2 px-3">Timestamp</th>
            <th className="text-left py-2 px-3">Action</th>
            <th className="text-left py-2 px-3">User</th>
            <th className="text-left py-2 px-3">IP</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, idx) => (
            <tr
              key={idx}
              className="border-b border-white/10 hover:bg-white/10"
            >
              <td className="py-2 px-3">{log.time}</td>
              <td className="py-2 px-3">{log.action}</td>
              <td className="py-2 px-3">{log.user}</td>
              <td className="py-2 px-3">{log.ip}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

LogsViewer.propTypes = {
  logs: PropTypes.arrayOf(
    PropTypes.shape({
      time: PropTypes.string,
      action: PropTypes.string,
      user: PropTypes.string,
      ip: PropTypes.string,
    }),
  ).isRequired,
};

export default LogsViewer;
