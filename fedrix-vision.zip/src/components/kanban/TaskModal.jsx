// src/components/kanban/TaskModal.jsx
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FaSave, FaTimesCircle, FaSpinner } from 'react-icons/fa';
import PropTypes from 'prop-types';
// import { useContext } from 'react'; // Removed unused useContext

const TaskModal = ({ task, onSave, onClose, columns }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'todo', // Default status
    due_date: '',
    priority: 'Medium', // Default priority
    tags: '', // Comma-separated tags
  });
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  useEffect(() => {
    if (task) {
      setFormData({
        title: task.title || '',
        description: task.description || '',
        status: task.status || 'todo',
        due_date: task.due_date
          ? new Date(task.due_date).toISOString().substring(0, 16)
          : '',
        priority: task.priority || 'Medium',
        tags: (task.tags || []).join(', '),
      });
    } else {
      // Reset for new task
      setFormData({
        title: '',
        description: '',
        status: 'todo',
        due_date: '',
        priority: 'Medium',
        tags: '',
      });
    }
  }, [task]);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage('');
    setMessageType('');

    try {
      const taskToSave = {
        ...formData,
        tags: formData.tags
          .split(',')
          .map((tag) => tag.trim())
          .filter((tag) => tag),
        id: task ? task.id : undefined, // Include ID if editing
      };
      await onSave(taskToSave);
      showMessage('Task saved successfully!', 'success');
      onClose();
    } catch (error) {
      console.error('Error saving task in modal:', error.message);
      showMessage(`Failed to save task: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black-ops bg-opacity-70 flex items-center justify-center z-50 p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="glass-effect p-8 rounded-xl shadow-2xl w-full max-w-md border border-mid-gray relative"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -50, opacity: 0 }}
      >
        <h2 className="text-2xl font-bold text-off-white mb-6">
          {task ? 'Edit Task' : 'Add New Task'}
        </h2>

        {message && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className={`p-3 mb-4 rounded-md text-sm ${
              messageType === 'success'
                ? 'bg-green-700/30 text-green-300 border border-green-500'
                : 'bg-red-700/30 text-red-300 border border-red-500'
            }`}
          >
            {message}
          </motion.div>
        )}

        <div className="space-y-4">
          <div>
            <label
              htmlFor="title"
              className="block text-light-gray text-sm font-bold mb-2"
            >
              Title:
            </label>
            <input
              type="text"
              id="title"
              name="title"
              className="email-input"
              value={formData.title}
              onChange={handleChange}
              disabled={isSaving}
            />
          </div>
          <div>
            <label
              htmlFor="description"
              className="block text-light-gray text-sm font-bold mb-2"
            >
              Description:
            </label>
            <textarea
              id="description"
              name="description"
              className="email-input min-h-[80px]"
              value={formData.description}
              onChange={handleChange}
              disabled={isSaving}
            ></textarea>
          </div>
          <div>
            <label
              htmlFor="status"
              className="block text-light-gray text-sm font-bold mb-2"
            >
              Status:
            </label>
            <select
              id="status"
              name="status"
              className="email-input"
              value={formData.status}
              onChange={handleChange}
              disabled={isSaving}
            >
              {Object.keys(columns).map((colKey) => (
                <option key={colKey} value={colKey}>
                  {columns[colKey].name}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="dueDate"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Due Date:
              </label>
              <input
                type="datetime-local"
                id="dueDate"
                name="due_date"
                className="email-input"
                value={formData.due_date}
                onChange={handleChange}
                disabled={isSaving}
              />
            </div>
            <div>
              <label
                htmlFor="priority"
                className="block text-light-gray text-sm font-bold mb-2"
              >
                Priority:
              </label>
              <select
                id="priority"
                name="priority"
                className="email-input"
                value={formData.priority}
                onChange={handleChange}
                disabled={isSaving}
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>
          <div>
            <label
              htmlFor="tags"
              className="block text-light-gray text-sm font-bold mb-2"
            >
              Tags (comma-separated):
            </label>
            <input
              type="text"
              id="tags"
              name="tags"
              className="email-input"
              value={formData.tags}
              onChange={handleChange}
              placeholder="e.g., urgent, marketing, bug"
              disabled={isSaving}
            />
          </div>
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <motion.button
            onClick={onClose}
            className="btn-primary bg-mid-gray hover:bg-dark-gray text-light-gray"
            disabled={isSaving}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaTimesCircle className="mr-2" /> Cancel
          </motion.button>
          <motion.button
            onClick={handleSave}
            className="btn-action"
            disabled={isSaving || !formData.title}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isSaving ? (
              <FaSpinner className="animate-spin mr-2" />
            ) : (
              <FaSave className="mr-2" />
            )}{' '}
            Save Task
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
};

TaskModal.propTypes = {
  task: PropTypes.object,
  onSave: PropTypes.func.isRequired,
  onClose: PropTypes.func.isRequired,
  columns: PropTypes.object.isRequired,
};

export default TaskModal;
