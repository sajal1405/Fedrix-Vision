// src/components/kanban/KanbanBoard.jsx
import React, { useState, useEffect, useCallback } from 'react'; // Added useCallback import
import { motion, AnimatePresence } from 'framer-motion';
import {
  FaPlus,
  FaTasks,
  FaSpinner,
  FaEdit,
  FaTrash,
  FaClipboardCheck,
} from 'react-icons/fa';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import TaskModal from './TaskModal';
import { supabase } from '../../supabaseClient';
import { useAuth } from '../../context/AuthContext';

const KanbanBoard = () => {
  const { currentUser } = useAuth();
  const [columns, setColumns] = useState({
    todo: {
      name: 'To Do',
      items: [],
      icon: <FaTasks className="text-red-400" />,
    },
    inProgress: {
      name: 'In Progress',
      items: [],
      icon: <FaSpinner className="text-yellow-400" />,
    },
    done: {
      name: 'Done',
      items: [],
      icon: <FaClipboardCheck className="text-green-400" />,
    },
  });
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  // Fetch tasks from Supabase - wrapped in useCallback
  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', currentUser?.id)
        .order('order', { ascending: true });

      if (error) throw error;

      const newColumns = {
        todo: { ...columns.todo, items: [] },
        inProgress: { ...columns.inProgress, items: [] },
        done: { ...columns.done, items: [] },
      };

      data.forEach((task) => {
        if (newColumns[task.status]) {
          newColumns[task.status].items.push(task);
        }
      });
      setColumns(newColumns);
    } catch (error) {
      console.error('Error fetching tasks:', error.message);
      showMessage('Failed to load tasks.', 'error');
    } finally {
      setLoading(false);
    }
  }, [currentUser?.id, columns]); // columns added as a dependency for fetchTasks

  useEffect(() => {
    if (currentUser?.id) {
      fetchTasks();

      const taskChannel = supabase
        .channel('public:tasks')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'tasks' },
          (payload) => {
            console.log('Task change received!', payload);
            fetchTasks();
          },
        )
        .subscribe();

      return () => {
        supabase.removeChannel(taskChannel);
      };
    }
  }, [currentUser?.id, fetchTasks]); // fetchTasks added as a dependency

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const onDragEnd = async (result) => {
    const { source, destination, draggableId } = result;

    if (!destination) return;

    const sourceColumnId = source.droppableId;
    const destColumnId = destination.droppableId;

    if (sourceColumnId === destColumnId) {
      const column = columns[sourceColumnId];
      const copiedItems = [...column.items];
      const [removed] = copiedItems.splice(source.index, 1);
      copiedItems.splice(destination.index, 0, removed);

      setColumns({
        ...columns,
        [sourceColumnId]: {
          ...column,
          items: copiedItems,
        },
      });
    } else {
      const sourceColumn = columns[sourceColumnId];
      const destColumn = columns[destColumnId];
      const sourceItems = [...sourceColumn.items];
      const destItems = [...destColumn.items];
      const [removed] = sourceItems.splice(source.index, 1);
      destItems.splice(destination.index, 0, removed);

      setColumns({
        ...columns,
        [sourceColumnId]: {
          ...sourceColumn,
          items: sourceItems,
        },
        [destColumnId]: {
          ...destColumn,
          items: destItems,
        },
      });

      const taskId = draggableId;
      try {
        const { error } = await supabase
          .from('tasks')
          .update({ status: destColumnId })
          .eq('id', taskId);
        if (error) throw error;
        showMessage(
          `Task status updated to ${destColumnId.charAt(0).toUpperCase() + destColumnId.slice(1)}.`,
          'success',
        );
      } catch (error) {
        console.error('Error updating task status:', error.message);
        showMessage('Failed to update task status.', 'error');
        setColumns({
          ...columns,
          [sourceColumnId]: {
            ...sourceColumn,
            items: [...sourceColumn.items, removed],
          },
          [destColumnId]: {
            ...destColumn,
            items: destItems.filter((item) => item.id !== removed.id),
          },
        });
      }
    }
  };

  const handleAddTask = () => {
    setCurrentTask(null);
    setShowModal(true);
  };

  const handleEditTask = (task) => {
    setCurrentTask(task);
    setShowModal(true);
  };

  const handleDeleteTask = async (taskId) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        const { error } = await supabase
          .from('tasks')
          .delete()
          .eq('id', taskId);

        if (error) throw error;
        showMessage('Task deleted successfully!', 'success');
        fetchTasks();
      } catch (error) {
        console.error('Error deleting task:', error.message);
        showMessage('Failed to delete task.', 'error');
      }
    }
  };

  const handleSaveTask = async (taskData) => {
    try {
      if (taskData.id) {
        const { error } = await supabase
          .from('tasks')
          .update({
            title: taskData.title,
            description: taskData.description,
            status: taskData.status,
            due_date: taskData.due_date,
            priority: taskData.priority,
            tags: taskData.tags,
          })
          .eq('id', taskData.id);
        if (error) throw error;
        showMessage('Task updated successfully!', 'success');
      } else {
        // eslint-disable-next-line no-unused-vars
        const { data, error } = await supabase // Mark `data` as intentionally unused
          .from('tasks')
          .insert({
            title: taskData.title,
            description: taskData.description,
            status: taskData.status,
            user_id: currentUser?.id,
            due_date: taskData.due_date,
            priority: taskData.priority,
            tags: taskData.tags,
            order: columns[taskData.status].items.length,
          })
          .select();
        if (error) throw error;
        showMessage('Task added successfully!', 'success');
      }
      setShowModal(false);
      fetchTasks();
    } catch (error) {
      console.error('Error saving task:', error.message);
      showMessage('Failed to save task.', 'error');
    }
  };

  return (
    <motion.div
      className="dashboard p-6 animate-fade-in flex flex-col h-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-6 text-off-white">Kanban Board</h1>

      {message && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={`p-3 mb-4 rounded-md text-sm ${
            messageType === 'success'
              ? 'bg-green-700/30 text-green-300 border border-green-500'
              : 'bg-red-700/30 text-red-300 border border-red-500'
          }`}
        >
          {message}
        </motion.div>
      )}

      <motion.button
        onClick={handleAddTask}
        className="btn-action mb-6 self-start flex items-center"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <FaPlus className="mr-2" /> Add New Task
      </motion.button>

      {loading ? (
        <div className="flex-grow flex items-center justify-center">
          <FaSpinner className="animate-spin text-teal-400 text-3xl mr-3" />
          <p className="text-light-gray text-lg">Loading tasks...</p>
        </div>
      ) : (
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-grow overflow-x-auto custom-scrollbar pb-4">
            {Object.entries(columns).map(([columnId, column]) => (
              <Droppable key={columnId} droppableId={columnId}>
                {(provided, snapshot) => (
                  <motion.div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`hologram-tile p-4 rounded-xl flex flex-col min-h-[300px]
                                ${snapshot.isDraggingOver ? 'bg-mid-gray/50' : 'bg-dark-gray/50'}
                                transition-colors duration-200`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.5,
                      delay: 0.1 * Object.keys(columns).indexOf(columnId),
                    }}
                  >
                    <h2 className="text-xl font-bold text-off-white mb-4 flex items-center gap-2">
                      {column.icon} {column.name} ({column.items.length})
                    </h2>
                    <div className="flex-grow overflow-y-auto custom-scrollbar pr-2 space-y-3">
                      {column.items.length === 0 && (
                        <p className="text-light-gray/70 text-sm text-center py-4">
                          No tasks here.
                        </p>
                      )}
                      <AnimatePresence>
                        {column.items.map((item, index) => (
                          <Draggable
                            key={item.id}
                            draggableId={item.id}
                            index={index}
                          >
                            {(provided, snapshot) => (
                              <motion.div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className={`bg-mid-gray p-4 rounded-lg shadow-md border
                                            ${snapshot.isDragging ? 'border-teal-400' : 'border-dark-gray'}
                                            text-light-gray cursor-grab flex items-center justify-between
                                            hover:bg-mid-gray/80 transition-colors duration-200`}
                                style={{
                                  ...provided.draggableProps.style,
                                }}
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                transition={{ duration: 0.2 }}
                              >
                                <div>
                                  <h3 className="font-semibold text-off-white">
                                    {item.title}
                                  </h3>
                                  <p className="text-sm line-clamp-2">
                                    {item.description}
                                  </p>
                                  {item.due_date && (
                                    <p className="text-xs text-mid-gray mt-1">
                                      Due:{' '}
                                      {new Date(
                                        item.due_date,
                                      ).toLocaleDateString()}
                                    </p>
                                  )}
                                  {item.priority && (
                                    <span
                                      className={`text-xs px-2 py-0.5 rounded-full mt-1 inline-block
                                                      ${
                                                        item.priority === 'High'
                                                          ? 'bg-red-700 text-red-100'
                                                          : item.priority ===
                                                              'Medium'
                                                            ? 'bg-yellow-700 text-yellow-100'
                                                            : 'bg-green-700 text-green-100'
                                                      }`}
                                    >
                                      {item.priority}
                                    </span>
                                  )}
                                </div>
                                <div className="flex flex-col space-y-2 ml-4 flex-shrink-0">
                                  <button
                                    onClick={() => handleEditTask(item)}
                                    className="p-2 rounded-full bg-dark-gray text-teal-400 hover:bg-black-ops transition-colors"
                                    title="Edit Task"
                                  >
                                    <FaEdit />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteTask(item.id)}
                                    className="p-2 rounded-full bg-dark-gray text-red-400 hover:bg-black-ops transition-colors"
                                    title="Delete Task"
                                  >
                                    <FaTrash />
                                  </button>
                                </div>
                              </motion.div>
                            )}
                          </Draggable>
                        ))}
                      </AnimatePresence>
                    </div>
                    {provided.placeholder}
                  </motion.div>
                )}
              </Droppable>
            ))}
          </div>
        </DragDropContext>
      )}

      <AnimatePresence>
        {showModal && (
          <TaskModal
            task={currentTask}
            onSave={handleSaveTask}
            onClose={() => setShowModal(false)}
            columns={columns}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default KanbanBoard;
