// src/components/kanban/TaskCard.jsx
// Represents a draggable task card within the Kanban board.
// It displays task details and provides options to edit or delete the task.
// Permissions for edit/delete are based on whether the current user created the task
// or if they are an admin/superadmin.
import React from 'react';
import PropTypes from 'prop-types'; // For type-checking component props
import { useDrag } from 'react-dnd'; // Hook for making the component draggable
import { FaEdit, FaTrash } from 'react-icons/fa'; // Icons for actions

const TaskCard = ({
  task,
  onEdit,
  onDelete,
  currentUserId,
  isCurrentUserAdmin,
}) => {
  // useDrag hook to make the component draggable.
  // 'type' is used by drop targets to specify what items they can accept.
  // 'item' is the data payload associated with the dragged item.
  // 'collect' function collects monitoring data about the drag state.
  const [{ isDragging }, dragRef] = useDrag({
    type: 'TASK_CARD', // Unique type for this draggable item
    item: { task }, // The task object itself is the item being dragged
    collect: (monitor) => ({
      isDragging: monitor.isDragging(), // True if this item is currently being dragged
    }),
  });

  // Determine if the current user has permission to edit or delete this task.
  // A user can manage a task if they created it OR if they are an admin/superadmin.
  const canManageTask = isCurrentUserAdmin || task.created_by === currentUserId;

  return (
    <div
      ref={dragRef} // Attach the drag reference to the DOM element
      className={`p-3 rounded-lg border mb-2 bg-black/40 text-white border-white/10 transition-all cursor-grab ${
        isDragging ? 'opacity-50 scale-95' : '' // Visual feedback when dragging
      }`}
    >
      <div className="flex justify-between items-center mb-1">
        {/* Task Title */}
        <strong className="text-lg text-white">{task.title}</strong>
        {/* Action Buttons (Edit, Delete) - Conditionally rendered based on permissions */}
        <div className="flex gap-2">
          {canManageTask && (
            <button
              onClick={() => onEdit(task)}
              className="text-yellow-400 hover:text-yellow-600 p-2 rounded-full hover:bg-white/10 transition-colors"
              title="Edit Task"
            >
              <FaEdit className="text-base" />
            </button>
          )}
          {canManageTask && (
            <button
              onClick={() => onDelete(task.id)}
              className="text-red-400 hover:text-red-600 p-2 rounded-full hover:bg-white/10 transition-colors"
              title="Delete Task"
            >
              <FaTrash className="text-base" />
            </button>
          )}
        </div>
      </div>
      {/* Task Description */}
      <p className="text-sm text-white/60 mb-2 line-clamp-2">
        {task.description}
      </p>
      {/* Task Tags (Priority, Custom Tag) */}
      <div className="flex flex-wrap gap-2">
        {task.priority && (
          <span className="px-2 py-1 rounded text-xs bg-yellow-500/10 border border-yellow-500 text-yellow-300">
            {task.priority}
          </span>
        )}
        {task.custom_tag && task.custom_color && (
          <span
            className="px-2 py-1 rounded text-xs"
            style={{
              backgroundColor: `${task.custom_color}20`, // Add transparency to custom color
              border: `1px solid ${task.custom_color}`,
              color: task.custom_color,
            }}
          >
            {task.custom_tag}
          </span>
        )}
      </div>
    </div>
  );
};

// PropTypes for TaskCard component to ensure correct prop types
TaskCard.propTypes = {
  task: PropTypes.shape({
    id: PropTypes.number,
    title: PropTypes.string.isRequired,
    description: PropTypes.string,
    status: PropTypes.string,
    priority: PropTypes.string,
    custom_tag: PropTypes.string,
    custom_color: PropTypes.string,
    created_by: PropTypes.string, // The ID of the user who created this task
  }).isRequired,
  onEdit: PropTypes.func.isRequired, // Callback for editing a task
  onDelete: PropTypes.func.isRequired, // Callback for deleting a task
  currentUserId: PropTypes.string, // The ID of the currently logged-in user
  isCurrentUserAdmin: PropTypes.bool, // True if the current user has admin/superadmin role
};

export default TaskCard;
