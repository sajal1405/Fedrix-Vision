// src/components/auth/LoginForm.jsx
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { motion } from 'framer-motion';
import { FaEnvelope, FaLock, FaGoogle, FaGithub } from 'react-icons/fa';
import LoginSlider from './LoginSlider';
import { useAuth } from '../../context/AuthContext';

const LoginForm = ({ onLoginSuccess, onForgotPassword, onRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { signIn: login = () => {}, isLoading } = useAuth();

  const handleLogin = async () => {
    setError('');
    setIsSubmitting(true);

    if (!email || !password) {
      setError('Please enter both email and password.');
      setIsSubmitting(false);
      return;
    }

    try {
      const { success, error: authError } = await login(email, password);

      if (success) {
        onLoginSuccess();
      } else {
        setError(authError || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      console.error('Login Error caught in LoginForm:', err);
      setError('An unexpected error occurred during login.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSliderComplete = () => {
    // Renamed from handleSliderSuccess for clarity with LoginSlider prop
    handleLogin();
  };

  const handleGoogleLogin = () => {
    setError('Google login not yet implemented.');
  };

  const handleGithubLogin = () => {
    setError('GitHub login not yet implemented.');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      // Use flex-col and justify-center to help vertical alignment within its container
      className="bg-dark-gray/60 backdrop-blur-md p-8 rounded-xl shadow-2xl border border-mid-gray max-w-md w-full flex flex-col justify-center"
    >
      <h2 className="text-3xl font-bold text-white mb-6 text-center">Login</h2>

      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-700/40 border border-red-500 text-white p-3 rounded-md mb-4 text-sm text-center"
        >
          {error}
        </motion.div>
      )}

      <form
        onSubmit={(e) => e.preventDefault()}
        className="flex flex-col flex-grow"
      >
        <div className="mb-4">
          <label
            className="block text-light-gray text-sm font-bold mb-2"
            htmlFor="email"
          >
            Email
          </label>
          <div className="relative">
            <FaEnvelope className="absolute left-3 top-1/2 transform -translate-y-1/2 text-light-gray" />
            <input
              type="email"
              id="email"
              className="email-input pl-10"
              placeholder="your@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={isSubmitting || isLoading}
            />
          </div>
        </div>
        <div className="mb-6">
          <label
            className="block text-light-gray text-sm font-bold mb-2"
            htmlFor="password"
          >
            Password
          </label>
          <div className="relative">
            <FaLock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-light-gray" />
            <input
              type="password"
              id="password"
              className="email-input pl-10"
              placeholder="********"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={isSubmitting || isLoading}
            />
          </div>
          <button
            type="button"
            onClick={onForgotPassword}
            className="text-teal-400 hover:text-teal-300 text-sm mt-2 float-right transition-colors"
            disabled={isSubmitting || isLoading}
          >
            Forgot Password?
          </button>
        </div>

        {/* Updated prop name to onSlideComplete */}
        <LoginSlider
          text="Slide to Login"
          onSlideComplete={handleSliderComplete}
          isLoading={isSubmitting || isLoading}
        />

        <div className="mt-8 text-center">
          <p className="text-light-gray mb-4">Or login with:</p>
          <div className="flex justify-center space-x-4">
            {' '}
            {/* Flexbox for horizontal centering of buttons */}
            <motion.button
              type="button"
              onClick={handleGoogleLogin}
              className="btn-primary flex items-center justify-center p-3 rounded-full bg-red-600 hover:bg-red-700 text-white"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              aria-label="Login with Google"
              disabled={isSubmitting || isLoading}
            >
              <FaGoogle className="text-xl" />
            </motion.button>
            <motion.button
              type="button"
              onClick={handleGithubLogin}
              className="btn-primary flex items-center justify-center p-3 rounded-full bg-gray-700 hover:bg-gray-800 text-white"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              aria-label="Login with GitHub"
              disabled={isSubmitting || isLoading}
            >
              <FaGithub className="text-xl" />
            </motion.button>
          </div>
          <p className="text-light-gray mt-6">
            Don&apos;t have an account?{' '}
            <button
              type="button"
              onClick={onRegister}
              className="text-teal-400 hover:text-teal-300 font-semibold transition-colors"
              disabled={isSubmitting || isLoading}
            >
              Register
            </button>
          </p>
        </div>
      </form>
    </motion.div>
  );
};

LoginForm.propTypes = {
  onLoginSuccess: PropTypes.func.isRequired,
  onForgotPassword: PropTypes.func.isRequired,
  onRegister: PropTypes.func.isRequired,
};

export default LoginForm;
