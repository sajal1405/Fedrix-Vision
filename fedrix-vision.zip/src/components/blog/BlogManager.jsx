// src/components/blog/BlogManager.jsx
import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabaseClient';
import BlogList from './BlogList';
import BlogEditor from './BlogEditor';
import { motion, AnimatePresence } from 'framer-motion';
import { FaSpinner } from 'react-icons/fa'; // Import FaSpinner
// eslint-disable-next-line no-unused-vars
import { useAuth } from '../../context/AuthContext'; // Marked as unused, keeping for potential future use or context
// eslint-disable-next-line no-unused-vars
import { useProfile } from '../../context/UserProfileContext'; // Marked as unused, keeping for potential future use or context

const BlogManager = () => {
  // eslint-disable-next-line no-unused-vars
  const { currentUser } = useAuth(); // Marked as unused, keeping for potential future use
  // eslint-disable-next-line no-unused-vars
  const { profile } = useProfile(); // Marked as unused, keeping for potential future use

  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingBlogId, setEditingBlogId] = useState(null);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  useEffect(() => {
    const fetchBlogs = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('blogs')
          .select('*')
          .order('published_at', { ascending: false });

        if (error) throw error;
        setBlogs(data || []);
      } catch (error) {
        console.error('Error fetching blogs:', error.message);
        showMessage('Failed to load blog posts.', 'error');
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();

    const blogChannel = supabase
      .channel('public:blogs')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'blogs' },
        (payload) => {
          console.log('Change received!', payload);
          fetchBlogs();
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(blogChannel);
    };
  }, []);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleEditBlog = (id) => {
    setEditingBlogId(id);
  };

  const handleAddBlog = () => {
    setEditingBlogId(null);
  };

  // eslint-disable-next-line no-unused-vars
  const handleSaveBlog = (newBlogData) => {
    // Marked as unused, keeping as it's a callback
    showMessage(
      newBlogData.id ? 'Blog updated successfully!' : 'New blog published!',
      'success',
    );
    setEditingBlogId(null);
  };

  // eslint-disable-next-line no-unused-vars
  const handleDeleteBlog = (deletedId) => {
    // Marked as unused, keeping as it's a callback
    showMessage('Blog deleted successfully!', 'success');
    setEditingBlogId(null);
  };

  const handleCancelEdit = () => {
    setEditingBlogId(null);
  };

  return (
    <motion.div
      className="dashboard p-6 animate-fade-in flex flex-col h-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {message && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className={`p-3 mb-4 rounded-md text-sm ${
            messageType === 'success'
              ? 'bg-green-700/30 text-green-300 border border-green-500'
              : 'bg-red-700/30 text-red-300 border border-red-500'
          }`}
        >
          {message}
        </motion.div>
      )}

      {loading ? (
        <div className="flex-grow flex items-center justify-center">
          <FaSpinner className="animate-spin text-teal-400 text-3xl mr-3" />
          <p className="text-light-gray text-lg">Loading blog posts...</p>
        </div>
      ) : (
        <AnimatePresence mode="wait">
          {editingBlogId !== null ? (
            <BlogEditor
              key="blog-editor"
              blogId={editingBlogId}
              onSave={handleSaveBlog}
              onCancel={handleCancelEdit}
              onDelete={handleDeleteBlog}
            />
          ) : (
            <BlogList
              key="blog-list"
              blogs={blogs}
              onEdit={handleEditBlog}
              onAdd={handleAddBlog}
              onDelete={handleDeleteBlog}
            />
          )}
        </AnimatePresence>
      )}
    </motion.div>
  );
};

export default BlogManager;
