// src/components/blog/BlogList.jsx
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaEdit, FaTrash, FaPlus } from 'react-icons/fa';
import PropTypes from 'prop-types'; // Keep this import as PropTypes is still used here

const BlogList = ({ blogs, onEdit, onAdd, onDelete }) => {
  return (
    <motion.div
      className="glass-effect p-6 rounded-xl shadow-lg border border-mid-gray flex flex-col h-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-off-white">Your Blog Posts</h2>
        <motion.button
          onClick={onAdd}
          className="btn-action"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <FaPlus className="mr-2" /> New Post
        </motion.button>
      </div>

      {blogs.length === 0 ? (
        <div className="flex-grow flex items-center justify-center">
          <p className="text-light-gray text-lg">
            No blog posts found. Click &quot;New Post&quot; to create one!
          </p>{' '}
          {/* Fixed unescaped entity */}
        </div>
      ) : (
        <div className="flex-grow overflow-y-auto custom-scrollbar pr-2">
          <AnimatePresence>
            <div className="space-y-4">
              {blogs.map((blog) => (
                <motion.div
                  key={blog.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                  className="hologram-tile p-4 flex flex-col md:flex-row items-start md:items-center justify-between space-y-3 md:space-y-0 md:space-x-4"
                >
                  <div className="flex-grow">
                    <h3 className="text-xl font-semibold text-off-white mb-1">
                      {blog.title}
                    </h3>
                    <p className="text-light-gray text-sm line-clamp-2">
                      {blog.content}
                    </p>
                    <p className="text-mid-gray text-xs mt-1">
                      {blog.author_name} -{' '}
                      {new Date(blog.published_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex space-x-2 flex-shrink-0">
                    <motion.button
                      onClick={() => onEdit(blog.id)}
                      className="btn-primary bg-teal-600 hover:bg-teal-700 text-off-white p-2 rounded-full"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <FaEdit />
                    </motion.button>
                    <motion.button
                      onClick={() => onDelete(blog.id)}
                      className="btn-primary bg-red-600 hover:bg-red-700 text-off-white p-2 rounded-full"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <FaTrash />
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </div>
          </AnimatePresence>
        </div>
      )}
    </motion.div>
  );
};

BlogList.propTypes = {
  blogs: PropTypes.array.isRequired,
  onEdit: PropTypes.func.isRequired,
  onAdd: PropTypes.func.isRequired,
  onDelete: PropTypes.func.isRequired,
};

export default BlogList;
