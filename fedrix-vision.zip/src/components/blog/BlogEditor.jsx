// src/components/blog/BlogEditor.jsx
import React, { useState, useEffect } from 'react'; // Removed useRef as it was unused
import { motion } from 'framer-motion';
import { FaSave, FaTrash, FaTimesCircle, FaSpinner } from 'react-icons/fa'; // Removed FaPlus, FaCheckCircle as they were unused
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { supabase } from '../../supabaseClient';
import { useAuth } from '../../context/AuthContext';
import { useProfile } from '../../context/UserProfileContext';
import PropTypes from 'prop-types';

const BlogEditor = ({ blogId, onSave, onCancel, onDelete }) => {
  const { currentUser } = useAuth();
  const { profile } = useProfile();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [loadingBlog, setLoadingBlog] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');

  useEffect(() => {
    if (blogId) {
      setLoadingBlog(true);
      const fetchBlog = async () => {
        try {
          const { data, error } = await supabase
            .from('blogs')
            .select('*')
            .eq('id', blogId)
            .single();

          if (error) throw error;
          if (data) {
            setTitle(data.title);
            setContent(data.content);
            setCategory(data.category);
            setImageUrl(data.image_url);
          }
        } catch (error) {
          console.error('Error fetching blog:', error.message);
          showMessage('Failed to load blog.', 'error');
        } finally {
          setLoadingBlog(false);
        }
      };
      fetchBlog();
    } else {
      setTitle('');
      setContent('');
      setCategory('');
      setImageUrl('');
    }
  }, [blogId]);

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage('');
    setMessageType('');

    const newBlog = {
      title,
      content,
      category,
      image_url: imageUrl,
      author_id: currentUser?.id,
      author_name: profile?.full_name || currentUser?.email,
      published_at: new Date().toISOString(),
    };

    try {
      if (blogId) {
        const { error } = await supabase
          .from('blogs')
          .update(newBlog)
          .eq('id', blogId);
        if (error) throw error;
        showMessage('Blog updated successfully!', 'success');
      } else {
        const { data, error } = await supabase
          .from('blogs')
          .insert(newBlog)
          .select();
        if (error) throw error;
        showMessage('Blog published successfully!', 'success');
        if (onSave) onSave(data[0]);
      }
    } catch (error) {
      console.error('Error saving blog:', error.message);
      showMessage(`Error saving blog: ${error.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!blogId) return;
    // IMPORTANT: In a real application, you should use a custom modal for confirmation,
    // not window.confirm(), as it blocks the UI and is not themable.
    if (
      window.confirm(
        'Are you sure you want to delete this blog post? This action cannot be undone.',
      )
    ) {
      setIsSaving(true);
      setMessage('');
      setMessageType('');
      try {
        const { error } = await supabase
          .from('blogs')
          .delete()
          .eq('id', blogId);
        if (error) throw error;
        showMessage('Blog deleted successfully!', 'success');
        if (onDelete) onDelete(blogId);
      } catch (error) {
        console.error('Error deleting blog:', error.message);
        showMessage(`Error deleting blog: ${error.message}`, 'error');
      } finally {
        setIsSaving(false);
      }
    }
  };

  if (loadingBlog) {
    return (
      <div className="flex justify-center items-center h-full min-h-[300px]">
        <FaSpinner className="animate-spin text-teal-400 text-3xl" />
        <p className="ml-3 text-light-gray">Loading blog...</p>
      </div>
    );
  }

  return (
    <motion.div
      className="glass-effect p-6 rounded-xl shadow-lg border border-mid-gray flex flex-col h-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-3xl font-bold text-off-white mb-6">
        {blogId ? 'Edit Blog Post' : 'Create New Blog Post'}
      </h2>

      {message && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className={`p-3 mb-4 rounded-md text-sm ${
            messageType === 'success'
              ? 'bg-green-700/30 text-green-300 border border-green-500'
              : 'bg-red-700/30 text-red-300 border border-red-500'
          }`}
        >
          {message}
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label
            htmlFor="title"
            className="block text-light-gray text-sm font-bold mb-2"
          >
            Title:
          </label>
          <input
            type="text"
            id="title"
            className="email-input"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter blog title"
            disabled={isSaving}
          />
        </div>
        <div>
          <label
            htmlFor="category"
            className="block text-light-gray text-sm font-bold mb-2"
          >
            Category:
          </label>
          <input
            type="text"
            id="category"
            className="email-input"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            placeholder="e.g., AI, Marketing, Development"
            disabled={isSaving}
          />
        </div>
        <div className="md:col-span-2">
          <label
            htmlFor="imageUrl"
            className="block text-light-gray text-sm font-bold mb-2"
          >
            Image URL:
          </label>
          <input
            type="url"
            id="imageUrl"
            className="email-input"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="Optional: URL to a featured image"
            disabled={isSaving}
          />
        </div>
      </div>

      <div className="flex-grow flex flex-col mb-6">
        <label
          htmlFor="content"
          className="block text-light-gray text-sm font-bold mb-2"
        >
          Content (Markdown):
        </label>
        <textarea
          id="content"
          className="email-input flex-grow min-h-[200px]"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Write your blog content here using Markdown..."
          disabled={isSaving}
        ></textarea>
        {content && (
          <div className="mt-4 p-4 bg-dark-gray/60 rounded-lg border border-mid-gray max-h-64 overflow-y-auto custom-scrollbar">
            <h3 className="text-light-gray text-lg font-semibold mb-2">
              Preview:
            </h3>
            <Markdown
              remarkPlugins={[remarkGfm]}
              className="prose prose-invert max-w-none"
            >
              {content}
            </Markdown>
          </div>
        )}
      </div>

      <div className="flex justify-end space-x-4 mt-auto">
        {blogId && (
          <motion.button
            onClick={handleDelete}
            className="btn-primary bg-red-600 hover:bg-red-700 text-off-white"
            disabled={isSaving}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaTrash className="mr-2" /> {isSaving ? 'Deleting...' : 'Delete'}
          </motion.button>
        )}
        <motion.button
          onClick={onCancel}
          className="btn-primary bg-mid-gray hover:bg-dark-gray text-light-gray"
          disabled={isSaving}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <FaTimesCircle className="mr-2" /> Cancel
        </motion.button>
        <motion.button
          onClick={handleSave}
          className="btn-action"
          disabled={isSaving || !title || !content}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {isSaving ? (
            <FaSpinner className="animate-spin mr-2" />
          ) : (
            <FaSave className="mr-2" />
          )}{' '}
          {blogId ? 'Update' : 'Publish'}
        </motion.button>
      </div>
    </motion.div>
  );
};

BlogEditor.propTypes = {
  blogId: PropTypes.string,
  onSave: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  onDelete: PropTypes.func,
};

export default BlogEditor;
