// src/supabaseClient.js
import { createClient } from '@supabase/supabase-js';

// Correctly access environment variables using REACT_APP_ prefix for Create React App
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL;
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY;

// Log to confirm environment variables are loaded
console.log('Supabase URL (from ENV):', supabaseUrl ? 'Loaded' : 'MISSING!');
console.log(
  'Supabase Anon Key (from ENV):',
  supabaseAnonKey ? 'Loaded' : 'MISSING!',
);

// Check for missing environment variables and provide a warning
if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    'CRITICAL ERROR: Supabase URL or Anon Key are missing from environment variables!',
  );
  console.error(
    'Please ensure REACT_APP_SUPABASE_URL and REACT_APP_SUPABASE_ANON_KEY are set in your .env file.',
  );
}

// Create and export the Supabase client instance
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
