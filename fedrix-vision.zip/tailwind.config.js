// tailwind.config.js
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  safelist: [
    'bg-black-ops',
    'text-off-white',
    'bg-dark-gray',
    'bg-mid-gray',
    'text-light-gray',
    'text-off-white',
    'text-teal-400',
    'text-cyan-400',
    'text-green-400',
    'text-yellow-400',
    'text-red-400',
    'bg-dark-gray/50',
    'border-mid-gray',
    'rounded-xl', // Add rounded-xl to safelist for consistent rounding
    'rounded-lg', // Also add rounded-lg
    'rounded-full', // For buttons/avatars
    // Add other specific classes if they are dynamically applied and not picked up
  ],
  theme: {
    extend: {
      colors: {
        'black-ops': '#0A0A0A',
        'dark-gray': '#1A1A1A',
        'mid-gray': '#333333',
        'light-gray': '#CCCCCC',
        'off-white': '#F5F5F5',

        'teal': {
          DEFAULT: "#14B8A6",
          100: "#CCFBF1", 200: "#99F6E4", 300: "#5EEAD4", 400: "#2DD4BF",
          500: "#14B8A6", 600: "#0D9488", 700: "#0F766E", 800: "#115E59", 900: "#134E4A",
        },
        'cyan': {
          DEFAULT: "#06B6D4",
          100: "#CFFAFE", 200: "#A5F3FC", 300: "#67E8F9", 400: "#22D3EE",
          500: "#06B6D4", 600: "#0891B2", 700: "#0E7490", 800: "#155E75", 900: "#164E63",
        },
        'green': {
          DEFAULT: "#22C55E",
          300: "#86EFAC", 400: "#4ADE80", 500: "#22C55E", 600: "#16A34A",
          700: "#15803D", 900: "#052E16",
        },
        'yellow': {
          DEFAULT: "#EAB308",
          300: "#FDE047", 400: "#FACC15", 500: "#EAB308", 600: "#CA8A04",
          700: "#A16207", 900: "#422006",
        },
        'red': {
          DEFAULT: "#EF4444",
          300: "#FCA5A5", 400: "#F87171", 500: "#EF4444", 600: "#DC2626",
          700: "#B91C1C", 900: "#450A0A",
        },
        'purple': { DEFAULT: "#8B5CF6" },
        'indigo': { DEFAULT: "#6366F1" },
      },
      fontFamily: {
        inter: ["Inter", "sans-serif"],
      },
      animation: {
        "fade-in": "fadeIn 1.5s ease-out",
        "slide-in": "slideIn 0.8s ease-out",
        "blob": "blob 7s infinite",
        "pulse-light": "pulse-light 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "hologram-pulse": "hologramPulse 4s infinite alternate ease-in-out",
        "float": "float 3s ease-in-out infinite",
        "fade-slide-in-up": "fadeSlideInUp 0.6s ease-out forwards", // For subtle entry animations
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: 0, transform: "translateY(10px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        },
        slideIn: {
          "0%": { transform: "translateX(100%)", opacity: 0 },
          "100%": { transform: "translateX(0)", opacity: 1 },
        },
        blob: {
          "0%": { transform: "translate(0px, 0px) scale(1)" },
          "33%": { transform: "translate(30px, -50px) scale(1.1)" },
          "66%": { transform: "translate(-20px, 20px) scale(0.9)" },
          "100%": { transform: "translate(0px, 0px) scale(1)" },
        },
        "pulse-light": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.7" },
        },
        hologramPulse: {
          "0%, 100%": {
            filter: "brightness(1) contrast(1)",
            boxShadow: "0 0 5px rgba(0, 255, 255, 0.2), 0 0 10px rgba(0, 255, 255, 0.1), inset 0 0 5px rgba(0, 255, 255, 0.1)",
            borderColor: "rgba(0, 255, 255, 0.3)",
          },
          "50%": {
            filter: "brightness(1.2) contrast(1.1)",
            boxShadow: "0 0 15px rgba(0, 255, 255, 0.4), 0 0 25px rgba(0, 255, 255, 0.2), inset 0 0 10px rgba(0, 255, 255, 0.2)",
            borderColor: "rgba(0, 255, 255, 0.6)",
          },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-5px)" },
        },
        fadeSlideInUp: {
          "0%": { opacity: 0, transform: "translateY(20px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        }
      },
      zIndex: {
        '0': 0, '10': 10, '20': 20, '30': 30, '40': 40, '50': 50, '60': 60, '70': 70, // Added higher z-indices
      }
    },
  },
  plugins: [
    require("@tailwindcss/typography"),
  ],
};
